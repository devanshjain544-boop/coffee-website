import React, { useState, useEffect } from "react";
import { Navbar } from "./components/Navbar";
import { CoffeeScene } from "./components/CoffeeScene";
import { Hero } from "./sections/Hero";
import { CoffeeSection } from "./sections/CoffeeSection";
import { BeanSection } from "./sections/BeanSection";
import { ProcessSection } from "./sections/ProcessSection";
import { SignatureSection } from "./sections/SignatureSection";
import { CollectionSection } from "./sections/CollectionSection";
import { StorySection } from "./sections/StorySection";
import { ExperienceSection } from "./sections/ExperienceSection";
import { FinalCTA } from "./sections/FinalCTA";
import { Footer } from "./components/Footer";
import { ProductQuickViewModal } from "./components/ProductQuickViewModal";
import { CartDrawer, CartItem } from "./components/CartDrawer";
import { PerspectiveShowcase } from "./components/PerspectiveShowcase";
import { Laptop3DExperience } from "./components/Laptop3DExperience";
import { ScrollProgressBar } from "./components/ScrollProgressBar";
import { brandConfig, Product } from "./config/brandConfig";
import { tapticEngine } from "./utils/tapticEngine";

export default function App() {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  // Default to the viral 3D Laptop Scroll Experience!
  const [viewMode, setViewMode] = useState<"3d-laptop" | "full-store">("3d-laptop");
  const [isPerspectiveShowcase, setIsPerspectiveShowcase] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Quick toast helper
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleAddToCart = (product: Product, grind: string = "Whole Bean") => {
    tapticEngine.trigger("medium");
    setCartItems((prev) => {
      const existing = prev.find(
        (item) => item.product.id === product.id && item.grind === grind
      );
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id && item.grind === grind
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, grind, quantity: 1 }];
    });
    showToast(`Added ${product.name} (${grind}) to cart`);
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    tapticEngine.trigger("light");
    if (quantity <= 0) {
      handleRemoveFromCart(productId);
      return;
    }
    setCartItems((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const handleRemoveFromCart = (productId: string) => {
    tapticEngine.trigger("light");
    setCartItems((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleCheckout = () => {
    tapticEngine.trigger("heavy");
    showToast("Thank you for sampling Aurelia Coffee! (Demo Checkout)");
    setIsCartOpen(false);
  };

  const scrollToCollection = () => {
    const el = document.getElementById("collection-section");
    if (el) {
      const navOffset = 80;
      const elementPosition = el.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - navOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      });
    }
  };

  const scrollToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      const navOffset = 80;
      const elementPosition = el.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - navOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      });
    }
  };

  // Main Page Content (reusable for normal view and within 3D angled laptop showcase)
  const renderWebsiteContent = () => (
    <div className="relative min-h-screen flex flex-col bg-[#0f0c0a] text-[#f4eee6]">
      {/* Slim Gold Scroll Progress Bar at very top of screen */}
      <ScrollProgressBar />

      {/* 3D WebGL Background Scene Canvas */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <CoffeeScene />
      </div>

      {/* Foreground Content Stack */}
      <div className="relative z-10 flex-1 flex flex-col">
        <Navbar
          isPerspectiveMode={isPerspectiveShowcase}
          onTogglePerspective={() => setIsPerspectiveShowcase(!isPerspectiveShowcase)}
          onEnter3DExperience={() => setViewMode("3d-laptop")}
          cartCount={cartItems.reduce((sum, item) => sum + item.quantity, 0)}
          onOpenCart={() => setIsCartOpen(true)}
        />

        <main className="flex-1">
          {/* Hero Section */}
          <Hero
            onExploreClick={() => scrollToSection("our-coffee")}
            onOpenPhilosophy={() => scrollToSection("story-section")}
          />

          {/* Section 01: Our Coffee */}
          <CoffeeSection
            onSelectCategory={() => scrollToCollection()}
          />

          {/* Section 02: The Beans */}
          <BeanSection />

          {/* Section 03: From Bean to Cup */}
          <ProcessSection />

          {/* Section 04: Signature Coffee */}
          <SignatureSection
            onDiscoverBlend={() => {
              const sig = brandConfig.products.find((p) => p.id === "aurelia-signature");
              if (sig) setSelectedProduct(sig);
              else scrollToCollection();
            }}
          />

          {/* Section 05: Coffee Collection */}
          <CollectionSection
            onViewProduct={(product) => setSelectedProduct(product)}
            onAddToCart={(product) => handleAddToCart(product)}
          />

          {/* Section 06: Our Story */}
          <StorySection />

          {/* Section 07: Experience */}
          <ExperienceSection />

          {/* Section 08: Final CTA */}
          <FinalCTA onShopClick={scrollToCollection} />
        </main>

        {/* Agency Footer */}
        <Footer />
      </div>
    </div>
  );

  return (
    <div className="bg-[#0f0c0a] text-[#f4eee6] min-h-screen">
      {/* 1. Viral 3D Laptop Scroll-Down Experience (Default Landing) */}
      {viewMode === "3d-laptop" && (
        <Laptop3DExperience onEnterStore={() => setViewMode("full-store")} />
      )}

      {/* 2. Full Standard Website */}
      {viewMode === "full-store" && !isPerspectiveShowcase && renderWebsiteContent()}

      {/* 3. Cinematic 3D Angled Device Showcase Mode */}
      {viewMode === "full-store" && isPerspectiveShowcase && (
        <PerspectiveShowcase
          isOpen={isPerspectiveShowcase}
          onClose={() => setIsPerspectiveShowcase(false)}
        >
          {renderWebsiteContent()}
        </PerspectiveShowcase>
      )}

      {/* Product Quick View Modal */}
      <ProductQuickViewModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={(product, grind) => handleAddToCart(product, grind)}
      />

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveFromCart}
        onCheckout={handleCheckout}
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 px-4 py-3 bg-[#191310] border border-[#c59d5f] text-xs font-mono text-[#f4eee6] shadow-2xl animate-in fade-in slide-in-from-bottom-2 duration-300 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#c59d5f]"></span>
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
