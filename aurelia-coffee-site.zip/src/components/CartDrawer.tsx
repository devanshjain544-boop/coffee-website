import React from "react";
import { Product } from "../config/brandConfig";
import { X, Trash2, ArrowRight, ShoppingBag } from "lucide-react";

export interface CartItem {
  product: Product;
  grind?: string;
  quantity: number;
}

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onCheckout: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
}) => {
  if (!isOpen) return null;

  // Calculate placeholder total in Indian Rupees
  const subtotal = items.reduce((sum, item) => {
    const numericPrice = parseFloat(item.product.price.replace(/[^0-9.]/g, "")) || 749;
    return sum + numericPrice * item.quantity;
  }, 0);

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-[#0a0807]/80 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="w-full max-w-md bg-[#130f0c] border-l border-[#2e2118] h-full flex flex-col justify-between shadow-2xl p-6 md:p-8 animate-in slide-in-from-right duration-300">
        {/* Header */}
        <div className="flex items-center justify-between pb-6 border-b border-[#2a1e16]">
          <div className="flex items-center gap-3">
            <ShoppingBag className="w-5 h-5 text-[#c59d5f]" />
            <h3 className="font-serif-luxury text-2xl text-[#f4eee6]">
              Your Ritual Cart
            </h3>
          </div>
          <button
            onClick={onClose}
            aria-label="Close cart"
            className="p-2 text-[#a8947f] hover:text-[#f4eee6] focus:outline-none"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Items List */}
        <div className="flex-1 overflow-y-auto py-6 space-y-6">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center text-[#8a7563] space-y-4">
              <ShoppingBag className="w-12 h-12 text-[#33241b]" />
              <p className="font-serif text-lg text-[#d6c7b2]">
                Your cart is currently empty.
              </p>
              <p className="text-xs max-w-xs">
                Explore our single estate roasts and select your signature roast.
              </p>
            </div>
          ) : (
            items.map((item) => (
              <div
                key={item.product.id}
                className="flex gap-4 p-4 bg-[#191310] border border-[#2c1f17]"
              >
                <div className="w-16 h-16 bg-[#0c0907] border border-[#2a1e16] p-1 shrink-0 flex items-center justify-center">
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-full h-full object-contain"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start">
                      <h4 className="font-serif text-base text-[#f4eee6]">
                        {item.product.name}
                      </h4>
                      <button
                        onClick={() => onRemoveItem(item.product.id)}
                        className="text-[#8a7563] hover:text-red-400 p-1"
                        title="Remove item"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <span className="text-[10px] text-[#c59d5f] block">
                      {item.grind || "Whole Bean"}
                    </span>
                  </div>

                  <div className="flex justify-between items-center mt-2 pt-2 border-t border-[#2a1e16]">
                    <div className="flex items-center border border-[#33241b]">
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                        className="px-2 py-0.5 text-xs text-[#a8947f] hover:text-[#f4eee6]"
                      >
                        -
                      </button>
                      <span className="px-2 text-xs font-mono text-[#f4eee6]">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                        className="px-2 py-0.5 text-xs text-[#a8947f] hover:text-[#f4eee6]"
                      >
                        +
                      </button>
                    </div>

                    <span className="font-mono text-sm text-[#f4eee6]">
                      {item.product.price}
                    </span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer with Checkout */}
        {items.length > 0 && (
          <div className="pt-6 border-t border-[#2a1e16] space-y-4">
            <div className="flex justify-between items-center text-xs uppercase tracking-wider text-[#a8947f]">
              <span>Complimentary Shipping</span>
              <span className="text-emerald-400 font-mono">FREE</span>
            </div>

            <div className="flex justify-between items-center">
              <span className="font-serif text-lg text-[#f4eee6]">Estimated Total</span>
              <span className="font-mono text-2xl text-[#c59d5f] font-semibold">
                ₹{subtotal.toLocaleString("en-IN")}
              </span>
            </div>

            <button
              onClick={onCheckout}
              className="w-full py-4 bg-[#c59d5f] hover:bg-[#dfbc84] text-[#0f0c0a] text-xs uppercase tracking-[0.25em] font-bold flex items-center justify-center gap-2 transition-all shadow-xl hover:shadow-[#c59d5f]/20 focus:outline-none"
            >
              <span>PROCEED TO CHECKOUT</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <p className="text-[10px] text-center text-[#8a7563]">
              Editable demo store • Hermetically sealed packaging
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
