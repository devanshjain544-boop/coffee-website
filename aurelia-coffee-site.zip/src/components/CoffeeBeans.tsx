import React, { useEffect, useRef } from "react";
import * as THREE from "three";
import { brandConfig } from "../config/brandConfig";

interface CoffeeBeansProps {
  className?: string;
  count?: number;
  interactive?: boolean;
}

export const createCoffeeBeansMeshGroup = (count: number = 14) => {
  const group = new THREE.Group();

  // Create bean geometry: squashed sphere with center longitudinal seam
  const beanGeo = new THREE.SphereGeometry(0.2, 16, 16);
  const pos = beanGeo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    let x = pos.getX(i) * 0.85;
    let y = pos.getY(i) * 1.4;
    let z = pos.getZ(i) * 0.65;
    if (z > 0 && Math.abs(x) < 0.06) {
      z -= (0.06 - Math.abs(x)) * 0.55;
    }
    pos.setXYZ(i, x, y, z);
  }
  beanGeo.computeVertexNormals();

  const beanMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color("#25150c"),
    roughness: 0.35,
    metalness: 0.18,
  });

  for (let i = 0; i < count; i++) {
    const mesh = new THREE.Mesh(beanGeo, beanMat);
    const angle = (i / count) * Math.PI * 2;
    const r = 1.0 + Math.random() * 1.2;
    mesh.position.set(
      Math.cos(angle) * r,
      (Math.random() - 0.5) * 1.5,
      Math.sin(angle) * r
    );
    mesh.rotation.set(
      Math.random() * Math.PI * 2,
      Math.random() * Math.PI * 2,
      Math.random() * Math.PI * 2
    );
    mesh.scale.setScalar(0.7 + Math.random() * 0.5);
    mesh.castShadow = true;
    group.add(mesh);
  }

  return group;
};

export const CoffeeBeans: React.FC<CoffeeBeansProps> = ({
  className = "w-full h-80",
  count = 14,
  interactive = true,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      45,
      container.clientWidth / container.clientHeight,
      0.1,
      100
    );
    camera.position.set(0, 0, 3.2);

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    } catch {
      return;
    }

    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);

    // Lighting
    const amb = new THREE.AmbientLight(0xffeedd, 0.9);
    scene.add(amb);

    const dir = new THREE.DirectionalLight(0xfffaed, 2.0);
    dir.position.set(2, 4, 3);
    scene.add(dir);

    const rim = new THREE.SpotLight(0xc59d5f, 3.0);
    rim.position.set(-2, 2, -2);
    scene.add(rim);

    const beansGroup = createCoffeeBeansMeshGroup(count);
    scene.add(beansGroup);

    let frameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      const t = clock.getElapsedTime();
      beansGroup.rotation.y = t * 0.25;
      beansGroup.rotation.x = Math.sin(t * 0.3) * 0.15;
      renderer.render(scene, camera);
      frameId = requestAnimationFrame(animate);
    };
    animate();

    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener("resize", handleResize);

    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener("resize", handleResize);
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [count, interactive]);

  return <div ref={containerRef} className={`relative ${className}`} />;
};
