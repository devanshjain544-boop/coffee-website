import React, { useEffect, useRef } from "react";
import * as THREE from "three";
import { brandConfig } from "../config/brandConfig";

interface CoffeeCupProps {
  className?: string;
  interactive?: boolean;
}

export const createCoffeeCupMeshGroup = () => {
  const group = new THREE.Group();

  // 1. Saucer Plate
  const saucerGeo = new THREE.CylinderGeometry(1.4, 0.9, 0.08, 64);
  const ceramicMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(brandConfig.threeD.saucerColor),
    roughness: 0.22,
    metalness: 0.12,
  });
  const saucer = new THREE.Mesh(saucerGeo, ceramicMat);
  saucer.position.y = -0.45;
  saucer.receiveShadow = true;
  group.add(saucer);

  // Saucer Gold Rim
  const saucerRimGeo = new THREE.TorusGeometry(1.38, 0.015, 16, 64);
  const goldMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(brandConfig.threeD.cupAccentColor),
    roughness: 0.25,
    metalness: 0.85,
  });
  const saucerRim = new THREE.Mesh(saucerRimGeo, goldMat);
  saucerRim.rotation.x = Math.PI / 2;
  saucerRim.position.y = -0.41;
  group.add(saucerRim);

  // 2. Ceramic Cup Body
  const cupBodyGeo = new THREE.CylinderGeometry(0.88, 0.6, 0.82, 64, 1, true);
  const cupBody = new THREE.Mesh(cupBodyGeo, ceramicMat);
  cupBody.castShadow = true;
  cupBody.receiveShadow = true;
  group.add(cupBody);

  // Cup Base
  const cupBaseGeo = new THREE.CylinderGeometry(0.6, 0.6, 0.06, 64);
  const cupBase = new THREE.Mesh(cupBaseGeo, ceramicMat);
  cupBase.position.y = -0.41;
  group.add(cupBase);

  // Cup Gold Lip Rim
  const cupRimGeo = new THREE.TorusGeometry(0.88, 0.018, 16, 64);
  const cupRim = new THREE.Mesh(cupRimGeo, goldMat);
  cupRim.rotation.x = Math.PI / 2;
  cupRim.position.y = 0.41;
  group.add(cupRim);

  // Cup Handle
  const handleGeo = new THREE.TorusGeometry(0.32, 0.07, 16, 32, Math.PI * 1.25);
  const handle = new THREE.Mesh(handleGeo, ceramicMat);
  handle.position.set(0.92, 0, 0);
  handle.rotation.z = -Math.PI / 10;
  group.add(handle);

  // 3. Coffee Liquid with Latte Art Crema
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext("2d");
  if (ctx) {
    const grad = ctx.createRadialGradient(256, 256, 10, 256, 256, 256);
    grad.addColorStop(0, "#2c1708");
    grad.addColorStop(0.5, "#6d3e14");
    grad.addColorStop(0.85, "#9e6833");
    grad.addColorStop(1, "#361c0c");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 512, 512);

    ctx.strokeStyle = "rgba(247, 241, 232, 0.9)";
    ctx.lineWidth = 14;
    ctx.lineCap = "round";

    ctx.beginPath();
    ctx.moveTo(256, 390);
    ctx.quadraticCurveTo(256, 250, 256, 120);
    ctx.stroke();

    for (let i = 0; i < 7; i++) {
      const y = 350 - i * 32;
      const spread = 24 + i * 11;
      ctx.beginPath();
      ctx.moveTo(256, y);
      ctx.quadraticCurveTo(256 - spread, y - 8, 256 - spread * 1.5, y - 24);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(256, y);
      ctx.quadraticCurveTo(256 + spread, y - 8, 256 + spread * 1.5, y - 24);
      ctx.stroke();
    }

    ctx.fillStyle = "rgba(247, 241, 232, 0.95)";
    ctx.beginPath();
    ctx.arc(256, 120, 20, 0, Math.PI * 2);
    ctx.fill();
  }
  const latteTexture = new THREE.CanvasTexture(canvas);

  const liquidGeo = new THREE.CircleGeometry(0.84, 64);
  const liquidMat = new THREE.MeshStandardMaterial({
    map: latteTexture,
    roughness: 0.35,
    metalness: 0.08,
  });
  const liquid = new THREE.Mesh(liquidGeo, liquidMat);
  liquid.rotation.x = -Math.PI / 2;
  liquid.position.y = 0.32;
  group.add(liquid);

  return group;
};

export const CoffeeCup: React.FC<CoffeeCupProps> = ({
  className = "w-full h-80",
  interactive = true,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      45,
      container.clientWidth / container.clientHeight,
      0.1,
      100
    );
    camera.position.set(0, 0.8, 2.8);

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    } catch {
      return;
    }

    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    container.appendChild(renderer.domElement);

    // Lighting
    const amb = new THREE.AmbientLight(0xffeedd, 0.8);
    scene.add(amb);

    const dir = new THREE.DirectionalLight(0xfffaed, 2.0);
    dir.position.set(3, 5, 4);
    scene.add(dir);

    const rim = new THREE.SpotLight(0xc59d5f, 3.5);
    rim.position.set(-3, 3, -2);
    scene.add(rim);

    const cupGroup = createCoffeeCupMeshGroup();
    cupGroup.position.set(0, -0.2, 0);
    scene.add(cupGroup);

    let mouseX = 0;
    let mouseY = 0;
    const handleMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      mouseX = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
      mouseY = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
    };

    if (interactive) {
      container.addEventListener("mousemove", handleMove);
    }

    let frameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      const t = clock.getElapsedTime();
      cupGroup.rotation.y = t * 0.4 + mouseX * 0.5;
      cupGroup.rotation.x = 0.2 + mouseY * 0.3;
      camera.lookAt(0, -0.1, 0);
      renderer.render(scene, camera);
      frameId = requestAnimationFrame(animate);
    };
    animate();

    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener("resize", handleResize);

    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener("resize", handleResize);
      if (interactive) {
        container.removeEventListener("mousemove", handleMove);
      }
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [interactive]);

  return <div ref={containerRef} className={`relative ${className}`} />;
};
