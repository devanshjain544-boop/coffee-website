import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { brandConfig } from "../config/brandConfig";

interface CoffeeExperience3DProps {
  currentStep: number;
  onStepChange?: (step: number) => void;
}

export const CoffeeExperience3D: React.FC<CoffeeExperience3DProps> = ({
  currentStep,
  onStepChange,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [webglSupported, setWebglSupported] = useState(true);

  // Store current step in ref for render loop without re-triggering effect
  const stepRef = useRef(currentStep);
  useEffect(() => {
    stepRef.current = currentStep;
  }, [currentStep]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        canvas,
        antialias: true,
        alpha: true,
        powerPreference: "high-performance",
      });
    } catch (e) {
      setWebglSupported(false);
      return;
    }

    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(canvas.clientWidth, canvas.clientHeight, false);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;

    const scene = new THREE.Scene();

    const camera = new THREE.PerspectiveCamera(
      45,
      canvas.clientWidth / canvas.clientHeight,
      0.1,
      100
    );
    camera.position.set(0, 0, 4.2);

    // ==========================================
    // LIGHTING (Dramatic, moody cafe studio)
    // ==========================================
    const ambientLight = new THREE.AmbientLight(0xffeedd, 0.7);
    scene.add(ambientLight);

    const goldSpot = new THREE.SpotLight(0xc59d5f, 4.0);
    goldSpot.position.set(4, 5, 3);
    goldSpot.angle = Math.PI / 3.5;
    goldSpot.penumbra = 0.8;
    goldSpot.castShadow = true;
    scene.add(goldSpot);

    const rimLight = new THREE.SpotLight(0xf4eee6, 3.0);
    rimLight.position.set(-4, 3, -3);
    rimLight.angle = Math.PI / 4;
    rimLight.penumbra = 0.7;
    scene.add(rimLight);

    const underGlow = new THREE.PointLight(0xb87333, 1.2, 8);
    underGlow.position.set(0, -2, 1);
    scene.add(underGlow);

    // ==========================================
    // STEP 0: EMBEDDED GOLDEN LOGO / SIGIL
    // ==========================================
    const logoGroup = new THREE.Group();
    scene.add(logoGroup);

    // Outer geometric rings
    const ringGeo1 = new THREE.TorusGeometry(1.2, 0.02, 16, 100);
    const ringGeo2 = new THREE.TorusGeometry(1.0, 0.015, 16, 80);
    const goldMaterial = new THREE.MeshStandardMaterial({
      color: 0xc59d5f,
      roughness: 0.2,
      metalness: 0.9,
    });
    const ring1 = new THREE.Mesh(ringGeo1, goldMaterial);
    const ring2 = new THREE.Mesh(ringGeo2, goldMaterial);
    ring2.rotation.x = Math.PI / 4;
    logoGroup.add(ring1);
    logoGroup.add(ring2);

    // Central faceted emblem diamond
    const emblemGeo = new THREE.OctahedronGeometry(0.55, 0);
    const emblemMat = new THREE.MeshStandardMaterial({
      color: 0xdfbc84,
      roughness: 0.15,
      metalness: 0.95,
      wireframe: false,
    });
    const emblem = new THREE.Mesh(emblemGeo, emblemMat);
    logoGroup.add(emblem);

    // Wireframe cage around emblem
    const cageGeo = new THREE.IcosahedronGeometry(0.75, 1);
    const cageMat = new THREE.MeshBasicMaterial({
      color: 0xc59d5f,
      wireframe: true,
      transparent: true,
      opacity: 0.35,
    });
    const cage = new THREE.Mesh(cageGeo, cageMat);
    logoGroup.add(cage);

    // ==========================================
    // STEP 1: FLOATING SPECIALTY COFFEE BEANS SWARM
    // ==========================================
    const beansGroup = new THREE.Group();
    scene.add(beansGroup);

    const beanSphere = new THREE.SphereGeometry(0.2, 16, 16);
    const bPos = beanSphere.attributes.position;
    for (let i = 0; i < bPos.count; i++) {
      let x = bPos.getX(i) * 0.85;
      let y = bPos.getY(i) * 1.4;
      let z = bPos.getZ(i) * 0.65;
      if (z > 0 && Math.abs(x) < 0.06) {
        z -= (0.06 - Math.abs(x)) * 0.5;
      }
      bPos.setXYZ(i, x, y, z);
    }
    beanSphere.computeVertexNormals();

    const beanMatDark = new THREE.MeshStandardMaterial({
      color: 0x221309,
      roughness: 0.35,
      metalness: 0.15,
    });
    const beanMatGold = new THREE.MeshStandardMaterial({
      color: 0xc59d5f,
      roughness: 0.25,
      metalness: 0.85,
    });

    const beanItems: {
      mesh: THREE.Mesh;
      basePos: THREE.Vector3;
      rotSpeed: THREE.Vector3;
      floatPhase: number;
    }[] = [];

    for (let i = 0; i < 28; i++) {
      const isGold = i % 7 === 0;
      const mesh = new THREE.Mesh(beanSphere, isGold ? beanMatGold : beanMatDark);
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);
      const r = 1.1 + Math.random() * 1.8;

      const pos = new THREE.Vector3(
        r * Math.sin(phi) * Math.cos(theta),
        r * Math.sin(phi) * Math.sin(theta),
        r * Math.cos(phi)
      );

      mesh.position.copy(pos);
      mesh.rotation.set(Math.random() * 6, Math.random() * 6, Math.random() * 6);
      mesh.scale.setScalar(0.7 + Math.random() * 0.6);
      beansGroup.add(mesh);

      beanItems.push({
        mesh,
        basePos: pos.clone(),
        rotSpeed: new THREE.Vector3(
          (Math.random() - 0.5) * 0.02,
          (Math.random() - 0.5) * 0.02,
          (Math.random() - 0.5) * 0.02
        ),
        floatPhase: Math.random() * Math.PI * 2,
      });
    }

    // ==========================================
    // STEP 2: METICULOUS EXTRACTION (Chemex / Pour-over Flask)
    // ==========================================
    const brewGroup = new THREE.Group();
    scene.add(brewGroup);

    // Glass Carafe Hourglass Profile
    const carafePoints: THREE.Vector2[] = [];
    carafePoints.push(new THREE.Vector2(0, -1.2));
    carafePoints.push(new THREE.Vector2(0.85, -1.2));
    carafePoints.push(new THREE.Vector2(0.9, -0.6));
    carafePoints.push(new THREE.Vector2(0.35, 0.1));
    carafePoints.push(new THREE.Vector2(0.4, 0.35));
    carafePoints.push(new THREE.Vector2(0.8, 1.1));
    carafePoints.push(new THREE.Vector2(0.82, 1.2));
    const carafeGeo = new THREE.LatheGeometry(carafePoints, 48);
    const glassMat = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      transmission: 0.88,
      opacity: 1,
      transparent: true,
      roughness: 0.08,
      ior: 1.52,
      metalness: 0.05,
    });
    const carafeMesh = new THREE.Mesh(carafeGeo, glassMat);
    brewGroup.add(carafeMesh);

    // Wood collar tie
    const collarGeo = new THREE.CylinderGeometry(0.42, 0.42, 0.28, 32);
    const woodMat = new THREE.MeshStandardMaterial({
      color: 0x8a5327,
      roughness: 0.6,
      metalness: 0.05,
    });
    const collar = new THREE.Mesh(collarGeo, woodMat);
    collar.position.y = 0.22;
    brewGroup.add(collar);

    // Liquid in the bottom of carafe
    const brewLiquidGeo = new THREE.CylinderGeometry(0.78, 0.72, 0.55, 32);
    const coffeeLiquidMat = new THREE.MeshStandardMaterial({
      color: 0x1f0e05,
      roughness: 0.2,
      metalness: 0.1,
      transparent: true,
      opacity: 0.95,
    });
    const brewLiquid = new THREE.Mesh(brewLiquidGeo, coffeeLiquidMat);
    brewLiquid.position.y = -0.85;
    brewGroup.add(brewLiquid);

    // Pouring stream
    const streamGeo = new THREE.CylinderGeometry(0.025, 0.03, 1.8, 16);
    const streamMat = new THREE.MeshStandardMaterial({
      color: 0x3d1c0b,
      roughness: 0.1,
      metalness: 0.2,
      transparent: true,
      opacity: 0.85,
    });
    const stream = new THREE.Mesh(streamGeo, streamMat);
    stream.position.set(0, 1.2, 0);
    brewGroup.add(stream);

    // ==========================================
    // STEP 3: LUXURY ESPRESSO CUP & LATTE ART
    // ==========================================
    const cupGroup = new THREE.Group();
    scene.add(cupGroup);

    // Saucer
    const saucerGeo = new THREE.CylinderGeometry(1.3, 0.8, 0.08, 48);
    const darkCeramic = new THREE.MeshStandardMaterial({
      color: 0x120e0c,
      roughness: 0.25,
      metalness: 0.2,
    });
    const saucer = new THREE.Mesh(saucerGeo, darkCeramic);
    saucer.position.y = -0.55;
    cupGroup.add(saucer);

    // Cup Body
    const cupGeo = new THREE.CylinderGeometry(0.85, 0.55, 0.85, 48);
    const cup = new THREE.Mesh(cupGeo, darkCeramic);
    cup.position.y = -0.1;
    cupGroup.add(cup);

    // Cup Lip Gold Ring
    const lipRingGeo = new THREE.TorusGeometry(0.85, 0.02, 16, 48);
    const lipRing = new THREE.Mesh(lipRingGeo, goldMaterial);
    lipRing.rotation.x = Math.PI / 2;
    lipRing.position.y = 0.32;
    cupGroup.add(lipRing);

    // Latte Art Top
    const artCanvas = document.createElement("canvas");
    artCanvas.width = 256;
    artCanvas.height = 256;
    const aCtx = artCanvas.getContext("2d");
    if (aCtx) {
      const g = aCtx.createRadialGradient(128, 128, 10, 128, 128, 128);
      g.addColorStop(0, "#2b1509");
      g.addColorStop(0.7, "#6e3f19");
      g.addColorStop(1, "#361b0a");
      aCtx.fillStyle = g;
      aCtx.fillRect(0, 0, 256, 256);

      // Heart / Rosetta
      aCtx.strokeStyle = "#f4eee6";
      aCtx.lineWidth = 8;
      aCtx.beginPath();
      aCtx.arc(128, 110, 24, 0, Math.PI * 2);
      aCtx.stroke();
      aCtx.fillStyle = "#f4eee6";
      aCtx.fill();
    }
    const latteArtTex = new THREE.CanvasTexture(artCanvas);
    const latteDisc = new THREE.Mesh(
      new THREE.CircleGeometry(0.81, 32),
      new THREE.MeshStandardMaterial({ map: latteArtTex, roughness: 0.4 })
    );
    latteDisc.rotation.x = -Math.PI / 2;
    latteDisc.position.y = 0.28;
    cupGroup.add(latteDisc);

    // Steam particles for cup
    const steamCount = 20;
    const steamGeo = new THREE.BufferGeometry();
    const steamPositions = new Float32Array(steamCount * 3);
    for (let i = 0; i < steamCount; i++) {
      steamPositions[i * 3] = (Math.random() - 0.5) * 0.4;
      steamPositions[i * 3 + 1] = 0.4 + Math.random() * 0.8;
      steamPositions[i * 3 + 2] = (Math.random() - 0.5) * 0.4;
    }
    steamGeo.setAttribute("position", new THREE.BufferAttribute(steamPositions, 3));
    const steamMat = new THREE.PointsMaterial({
      size: 0.1,
      color: 0xf4eee6,
      transparent: true,
      opacity: 0.35,
      blending: THREE.AdditiveBlending,
    });
    const steam = new THREE.Points(steamGeo, steamMat);
    cupGroup.add(steam);

    // ==========================================
    // STEP 4: SIGNATURE BOTTLE / CANISTER
    // ==========================================
    const productGroup = new THREE.Group();
    scene.add(productGroup);

    // Matte black coffee tin cylinder
    const tinGeo = new THREE.CylinderGeometry(0.75, 0.75, 1.8, 48);
    const tinMat = new THREE.MeshStandardMaterial({
      color: 0x181412,
      roughness: 0.35,
      metalness: 0.3,
    });
    const tin = new THREE.Mesh(tinGeo, tinMat);
    productGroup.add(tin);

    // Gold Lid
    const lidGeo = new THREE.CylinderGeometry(0.78, 0.78, 0.15, 48);
    const lid = new THREE.Mesh(lidGeo, goldMaterial);
    lid.position.y = 0.95;
    productGroup.add(lid);

    // Gold label band
    const labelGeo = new THREE.CylinderGeometry(0.76, 0.76, 0.7, 48);
    const labelMat = new THREE.MeshStandardMaterial({
      color: 0x241c17,
      roughness: 0.5,
      metalness: 0.1,
    });
    const label = new THREE.Mesh(labelGeo, labelMat);
    label.position.y = -0.1;
    productGroup.add(label);

    // Golden foil emblem on label
    const sealGeo = new THREE.CircleGeometry(0.2, 24);
    const seal = new THREE.Mesh(sealGeo, goldMaterial);
    seal.position.set(0, -0.1, 0.77);
    productGroup.add(seal);

    // ==========================================
    // AMBIENT GOLD DUST
    // ==========================================
    const dustCount = 80;
    const dustGeo = new THREE.BufferGeometry();
    const dustPos = new Float32Array(dustCount * 3);
    for (let i = 0; i < dustCount; i++) {
      dustPos[i * 3] = (Math.random() - 0.5) * 8;
      dustPos[i * 3 + 1] = (Math.random() - 0.5) * 6;
      dustPos[i * 3 + 2] = (Math.random() - 0.5) * 6;
    }
    dustGeo.setAttribute("position", new THREE.BufferAttribute(dustPos, 3));
    const dustMat = new THREE.PointsMaterial({
      size: 0.04,
      color: 0xc59d5f,
      transparent: true,
      opacity: 0.5,
      blending: THREE.AdditiveBlending,
    });
    const dustParticles = new THREE.Points(dustGeo, dustMat);
    scene.add(dustParticles);

    // ==========================================
    // MOUSE PARALLAX & RESIZE
    // ==========================================
    let mouseX = 0;
    let mouseY = 0;
    const onMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouseX = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
      mouseY = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
    };
    window.addEventListener("mousemove", onMouseMove);

    const onResize = () => {
      if (!canvas) return;
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      if (w === 0 || h === 0) return;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h, false);
    };
    const ro = new ResizeObserver(onResize);
    ro.observe(canvas);

    // ==========================================
    // RENDER ANIMATION LOOP
    // ==========================================
    let animId: number;
    let clock = new THREE.Clock();

    // Lerp helper
    const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

    const render = () => {
      const time = clock.getElapsedTime();
      const current = stepRef.current;

      // Group visibility & scale transitions based on current step
      // Step 0: Sigil / Logo
      const t0 = current === 0 ? 1 : 0;
      logoGroup.scale.setScalar(lerp(logoGroup.scale.x, t0 ? 1 : 0.001, 0.08));
      logoGroup.rotation.y = time * 0.4 + mouseX * 0.3;
      logoGroup.rotation.x = Math.sin(time * 0.6) * 0.15 - mouseY * 0.2;
      emblem.rotation.y = -time * 0.6;
      emblem.rotation.x = time * 0.4;
      ring1.rotation.z = time * 0.2;
      ring2.rotation.z = -time * 0.25;

      // Step 1: Beans cluster
      const t1 = current === 1 ? 1 : 0;
      beansGroup.scale.setScalar(lerp(beansGroup.scale.x, t1 ? 1 : 0.001, 0.08));
      beansGroup.rotation.y = time * 0.25 + mouseX * 0.3;
      beansGroup.rotation.x = Math.sin(time * 0.3) * 0.15 - mouseY * 0.2;
      beanItems.forEach((b, i) => {
        b.mesh.rotation.x += b.rotSpeed.x;
        b.mesh.rotation.y += b.rotSpeed.y;
        b.mesh.position.y = b.basePos.y + Math.sin(time * 1.5 + b.floatPhase) * 0.15;
      });

      // Step 2: Extraction Flask
      const t2 = current === 2 ? 1 : 0;
      brewGroup.scale.setScalar(lerp(brewGroup.scale.x, t2 ? 1.05 : 0.001, 0.08));
      brewGroup.rotation.y = -0.3 + Math.sin(time * 0.5) * 0.15 + mouseX * 0.2;
      brewGroup.rotation.x = 0.2 - mouseY * 0.15;
      stream.scale.y = 1 + Math.sin(time * 6) * 0.08;

      // Step 3: Espresso Cup & Latte Art
      const t3 = current === 3 ? 1 : 0;
      cupGroup.scale.setScalar(lerp(cupGroup.scale.x, t3 ? 1.1 : 0.001, 0.08));
      cupGroup.rotation.y = 0.3 + time * 0.2 + mouseX * 0.25;
      cupGroup.rotation.x = 0.35 + Math.sin(time * 0.8) * 0.05 - mouseY * 0.2;

      // Step 4: Signature Tin Product
      const t4 = current === 4 ? 1 : 0;
      productGroup.scale.setScalar(lerp(productGroup.scale.x, t4 ? 1.15 : 0.001, 0.08));
      productGroup.rotation.y = time * 0.4 + mouseX * 0.3;
      productGroup.rotation.x = 0.1 - mouseY * 0.15;

      // Dust motion
      dustParticles.rotation.y = time * 0.03;
      dustParticles.position.y = Math.sin(time * 0.4) * 0.1;

      // Camera subtle breathing
      camera.position.x = lerp(camera.position.x, mouseX * 0.3, 0.05);
      camera.position.y = lerp(camera.position.y, -mouseY * 0.3, 0.05);
      camera.lookAt(0, 0, 0);

      renderer.render(scene, camera);
      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("mousemove", onMouseMove);
      ro.disconnect();
      renderer.dispose();
      scene.clear();
    };
  }, []);

  if (!webglSupported) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-[#140f0c]">
        <img
          src={brandConfig.images.heroCoffee}
          alt="Aurelia Coffee 3D"
          className="w-48 h-48 object-cover rounded-full opacity-60"
          referrerPolicy="no-referrer"
        />
      </div>
    );
  }

  return (
    <canvas
      ref={canvasRef}
      className="w-full h-full block pointer-events-none"
      aria-label="3D Coffee Experience Scene"
    />
  );
};
