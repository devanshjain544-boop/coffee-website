import React, { useEffect, useRef } from "react";
import * as THREE from "three";
import { brandConfig } from "../config/brandConfig";

interface CoffeePackageProps {
  className?: string;
  interactive?: boolean;
}

export const createCoffeePackageMeshGroup = () => {
  const group = new THREE.Group();

  // Procedural label texture
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 768;
  const ctx = canvas.getContext("2d");
  if (ctx) {
    ctx.fillStyle = "#161210";
    ctx.fillRect(0, 0, 512, 768);

    ctx.strokeStyle = "#c59d5f";
    ctx.lineWidth = 4;
    ctx.strokeRect(24, 24, 464, 720);

    ctx.lineWidth = 1.5;
    ctx.strokeRect(36, 36, 440, 696);

    ctx.fillStyle = "#c59d5f";
    ctx.font = "bold 34px 'Cormorant Garamond', Georgia, serif";
    ctx.textAlign = "center";
    ctx.fillText("A U R E L I A", 256, 120);

    ctx.fillStyle = "#f4eee6";
    ctx.font = "14px sans-serif";
    ctx.letterSpacing = "6px";
    ctx.fillText("SPECIALTY ROASTERS", 256, 160);

    ctx.strokeStyle = "rgba(197, 157, 95, 0.4)";
    ctx.beginPath();
    ctx.moveTo(100, 200);
    ctx.lineTo(412, 200);
    ctx.stroke();

    ctx.fillStyle = "#c59d5f";
    ctx.font = "italic 36px 'Cormorant Garamond', Georgia, serif";
    ctx.fillText("Signature Reserve", 256, 270);

    ctx.fillStyle = "#d6c7b2";
    ctx.font = "14px sans-serif";
    ctx.fillText("SINGLE ORIGIN MICROLOT", 256, 310);
    ctx.fillText("HUILA, COLOMBIA • 1,950M", 256, 340);

    ctx.fillStyle = "#221a15";
    ctx.fillRect(80, 420, 352, 100);
    ctx.strokeStyle = "#a8947f";
    ctx.strokeRect(80, 420, 352, 100);

    ctx.fillStyle = "#f4eee6";
    ctx.font = "13px sans-serif";
    ctx.fillText("TASTING NOTES", 256, 455);
    ctx.fillStyle = "#c59d5f";
    ctx.font = "bold 15px sans-serif";
    ctx.fillText("Bergamot • Honeycomb • Cacao", 256, 490);

    ctx.fillStyle = "#8a7563";
    ctx.font = "13px sans-serif";
    ctx.fillText("250G / 8.8 OZ WHOLE BEAN", 256, 620);
  }
  const labelTexture = new THREE.CanvasTexture(canvas);

  // Bag Body
  const bagGeo = new THREE.BoxGeometry(1.1, 1.6, 0.65);
  const bagMat = new THREE.MeshStandardMaterial({
    color: 0x181310,
    roughness: 0.65,
    metalness: 0.1,
  });
  const bagMesh = new THREE.Mesh(bagGeo, bagMat);
  bagMesh.position.y = 0.2;
  bagMesh.castShadow = true;
  group.add(bagMesh);

  // Label Plane
  const labelGeo = new THREE.PlaneGeometry(0.9, 1.4);
  const labelMat = new THREE.MeshStandardMaterial({
    map: labelTexture,
    roughness: 0.4,
    metalness: 0.2,
  });
  const labelMesh = new THREE.Mesh(labelGeo, labelMat);
  labelMesh.position.set(0, 0.2, 0.33);
  group.add(labelMesh);

  // Top Seal
  const sealGeo = new THREE.BoxGeometry(1.15, 0.12, 0.08);
  const sealMat = new THREE.MeshStandardMaterial({
    color: 0xc59d5f,
    roughness: 0.3,
    metalness: 0.8,
  });
  const sealMesh = new THREE.Mesh(sealGeo, sealMat);
  sealMesh.position.set(0, 1.05, 0);
  group.add(sealMesh);

  // Aroma Degassing Valve
  const valveGeo = new THREE.CylinderGeometry(0.08, 0.08, 0.02, 32);
  const valveMat = new THREE.MeshStandardMaterial({
    color: 0x2a221b,
    roughness: 0.3,
    metalness: 0.5,
  });
  const valveMesh = new THREE.Mesh(valveGeo, valveMat);
  valveMesh.rotation.x = Math.PI / 2;
  valveMesh.position.set(0, 0.75, 0.34);
  group.add(valveMesh);

  return group;
};

export const CoffeePackage: React.FC<CoffeePackageProps> = ({
  className = "w-full h-80",
  interactive = true,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      45,
      container.clientWidth / container.clientHeight,
      0.1,
      100
    );
    camera.position.set(0, 0.2, 3.2);

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    } catch {
      return;
    }

    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);

    const amb = new THREE.AmbientLight(0xffeedd, 0.9);
    scene.add(amb);

    const dir = new THREE.DirectionalLight(0xfffaed, 2.2);
    dir.position.set(3, 4, 3);
    scene.add(dir);

    const rim = new THREE.SpotLight(0xc59d5f, 3.5);
    rim.position.set(-2, 3, -2);
    scene.add(rim);

    const pkgGroup = createCoffeePackageMeshGroup();
    scene.add(pkgGroup);

    let frameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      const t = clock.getElapsedTime();
      pkgGroup.rotation.y = Math.sin(t * 0.4) * 0.4;
      renderer.render(scene, camera);
      frameId = requestAnimationFrame(animate);
    };
    animate();

    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener("resize", handleResize);

    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener("resize", handleResize);
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [interactive]);

  return <div ref={containerRef} className={`relative ${className}`} />;
};
