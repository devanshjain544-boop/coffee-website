import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { brandConfig } from "../config/brandConfig";

interface CoffeeSceneProps {
  className?: string;
  scrollYProgress?: number;
  interactive?: boolean;
}

export const CoffeeScene: React.FC<CoffeeSceneProps> = ({
  className = "",
  interactive = true,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isWebGLAvailable, setIsWebGLAvailable] = useState(true);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        canvas,
        antialias: true,
        alpha: true,
        powerPreference: "high-performance",
      });
    } catch (e) {
      console.warn("WebGL not supported or context lost:", e);
      setIsWebGLAvailable(false);
      return;
    }

    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(canvas.clientWidth, canvas.clientHeight, false);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;

    // Scene setup
    const scene = new THREE.Scene();

    // Camera setup
    const camera = new THREE.PerspectiveCamera(
      brandConfig.animation.cameraFov,
      canvas.clientWidth / canvas.clientHeight,
      0.1,
      100
    );
    camera.position.set(0, 0.7, 2.7);

    // ==========================================
    // LIGHTING (Warm cinematic luxury coffee mood)
    // ==========================================
    // 1. Ambient warm fill
    const ambientLight = new THREE.AmbientLight(0xffeedd, 0.6);
    scene.add(ambientLight);

    // 2. Key directional light (warm morning sun)
    const keyLight = new THREE.DirectionalLight(0xfffaed, 2.2);
    keyLight.position.set(3, 5, 4);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    keyLight.shadow.camera.near = 0.5;
    keyLight.shadow.camera.far = 15;
    keyLight.shadow.bias = -0.0005;
    scene.add(keyLight);

    // 3. Golden Rim light (creates luxury silhouette on cup & beans)
    const rimLight = new THREE.SpotLight(0xc59d5f, 4.5);
    rimLight.position.set(-3, 3, -2);
    rimLight.angle = Math.PI / 4;
    rimLight.penumbra = 0.8;
    scene.add(rimLight);

    // 4. Subtle cool blue-gray counter fill
    const fillLight = new THREE.DirectionalLight(0x7b8d9e, 0.5);
    fillLight.position.set(-4, -1, 2);
    scene.add(fillLight);

    // ==========================================
    // PROCEDURAL 3D OBJECTS
    // ==========================================

    // Master Hero Coffee Group
    const heroGroup = new THREE.Group();
    scene.add(heroGroup);

    // --- 1. Procedural Latte Art Disc ---
    const latteArtCanvas = document.createElement("canvas");
    latteArtCanvas.width = 512;
    latteArtCanvas.height = 512;
    const ctx = latteArtCanvas.getContext("2d");
    if (ctx) {
      // Coffee Crema gradient
      const grad = ctx.createRadialGradient(256, 256, 10, 256, 256, 256);
      grad.addColorStop(0, "#2c1708");
      grad.addColorStop(0.5, "#6d3e14");
      grad.addColorStop(0.85, "#9e6833");
      grad.addColorStop(1, "#361c0c");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 512, 512);

      // Micro-foam Rosetta art
      ctx.strokeStyle = "rgba(247, 241, 232, 0.9)";
      ctx.lineWidth = 14;
      ctx.lineCap = "round";

      // Center stem
      ctx.beginPath();
      ctx.moveTo(256, 390);
      ctx.quadraticCurveTo(256, 250, 256, 120);
      ctx.stroke();

      // Fern leaves
      for (let i = 0; i < 7; i++) {
        const y = 350 - i * 32;
        const spread = 24 + i * 11;
        ctx.beginPath();
        ctx.moveTo(256, y);
        ctx.quadraticCurveTo(256 - spread, y - 8, 256 - spread * 1.5, y - 24);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(256, y);
        ctx.quadraticCurveTo(256 + spread, y - 8, 256 + spread * 1.5, y - 24);
        ctx.stroke();
      }

      // Top heart
      ctx.fillStyle = "rgba(247, 241, 232, 0.95)";
      ctx.beginPath();
      ctx.arc(256, 120, 20, 0, Math.PI * 2);
      ctx.fill();
    }
    const latteTexture = new THREE.CanvasTexture(latteArtCanvas);

    // Cup Group
    const cupGroup = new THREE.Group();

    // Saucer
    const saucerGeo = new THREE.CylinderGeometry(1.4, 0.9, 0.08, 64);
    const ceramicMat = new THREE.MeshStandardMaterial({
      color: 0x161311,
      roughness: 0.22,
      metalness: 0.12,
    });
    const saucer = new THREE.Mesh(saucerGeo, ceramicMat);
    saucer.position.y = -0.45;
    saucer.receiveShadow = true;
    cupGroup.add(saucer);

    // Saucer gold rim
    const saucerRimGeo = new THREE.TorusGeometry(1.38, 0.015, 16, 64);
    const goldMat = new THREE.MeshStandardMaterial({
      color: 0xc59d5f,
      roughness: 0.25,
      metalness: 0.85,
    });
    const saucerRim = new THREE.Mesh(saucerRimGeo, goldMat);
    saucerRim.rotation.x = Math.PI / 2;
    saucerRim.position.y = -0.41;
    cupGroup.add(saucerRim);

    // Cup Body
    const cupBodyGeo = new THREE.CylinderGeometry(0.88, 0.6, 0.82, 64, 1, true);
    const cupBody = new THREE.Mesh(cupBodyGeo, ceramicMat);
    cupBody.castShadow = true;
    cupBody.receiveShadow = true;
    cupGroup.add(cupBody);

    // Cup Base
    const cupBaseGeo = new THREE.CylinderGeometry(0.6, 0.6, 0.06, 64);
    const cupBase = new THREE.Mesh(cupBaseGeo, ceramicMat);
    cupBase.position.y = -0.41;
    cupGroup.add(cupBase);

    // Cup Gold Lip Rim
    const cupRimGeo = new THREE.TorusGeometry(0.88, 0.018, 16, 64);
    const cupRim = new THREE.Mesh(cupRimGeo, goldMat);
    cupRim.rotation.x = Math.PI / 2;
    cupRim.position.y = 0.41;
    cupGroup.add(cupRim);

    // Cup Handle
    const handleGeo = new THREE.TorusGeometry(0.32, 0.07, 16, 32, Math.PI * 1.25);
    const handle = new THREE.Mesh(handleGeo, ceramicMat);
    handle.position.set(0.92, 0, 0);
    handle.rotation.z = -Math.PI / 10;
    cupGroup.add(handle);

    // Coffee Liquid with Latte Art
    const liquidGeo = new THREE.CircleGeometry(0.84, 64);
    const liquidMat = new THREE.MeshStandardMaterial({
      map: latteTexture,
      roughness: 0.35,
      metalness: 0.08,
    });
    const liquid = new THREE.Mesh(liquidGeo, liquidMat);
    liquid.rotation.x = -Math.PI / 2;
    liquid.position.y = 0.32;
    cupGroup.add(liquid);

    heroGroup.add(cupGroup);

    // --- 2. Rising Steam Particle System ---
    const steamCount = 36;
    const steamGeo = new THREE.BufferGeometry();
    const steamPositions = new Float32Array(steamCount * 3);
    const steamVelocities: { x: number; y: number; z: number; age: number; maxAge: number }[] = [];

    for (let i = 0; i < steamCount; i++) {
      steamPositions[i * 3] = (Math.random() - 0.5) * 0.4;
      steamPositions[i * 3 + 1] = 0.4 + Math.random() * 0.8;
      steamPositions[i * 3 + 2] = (Math.random() - 0.5) * 0.4;
      steamVelocities.push({
        x: (Math.random() - 0.5) * 0.003,
        y: 0.004 + Math.random() * 0.006,
        z: (Math.random() - 0.5) * 0.003,
        age: Math.random() * 100,
        maxAge: 100 + Math.random() * 60,
      });
    }
    steamGeo.setAttribute("position", new THREE.BufferAttribute(steamPositions, 3));
    const steamMat = new THREE.PointsMaterial({
      size: 0.12,
      color: 0xf4eee6,
      transparent: true,
      opacity: 0.28,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const steam = new THREE.Points(steamGeo, steamMat);
    heroGroup.add(steam);

    // --- 3. Floating 3D Coffee Beans Cluster ---
    const beanCount = brandConfig.threeD.beanCount;
    const beansGroup = new THREE.Group();
    scene.add(beansGroup);

    // Create realistic bean geometry
    const beanSphere = new THREE.SphereGeometry(0.18, 16, 16);
    const bPos = beanSphere.attributes.position;
    for (let i = 0; i < bPos.count; i++) {
      let x = bPos.getX(i) * 0.85;
      let y = bPos.getY(i) * 1.4;
      let z = bPos.getZ(i) * 0.65;
      if (z > 0 && Math.abs(x) < 0.06) {
        z -= (0.06 - Math.abs(x)) * 0.5;
      }
      bPos.setXYZ(i, x, y, z);
    }
    beanSphere.computeVertexNormals();

    const beanMat = new THREE.MeshStandardMaterial({
      color: 0x24150c,
      roughness: 0.38,
      metalness: 0.15,
    });

    const beansData: {
      mesh: THREE.Mesh;
      origPos: THREE.Vector3;
      rotSpeed: THREE.Vector3;
      floatSpeed: number;
      orbitRadius: number;
      orbitAngle: number;
    }[] = [];

    for (let i = 0; i < beanCount; i++) {
      const beanMesh = new THREE.Mesh(beanSphere, beanMat);
      const angle = (i / beanCount) * Math.PI * 2;
      const radius = 1.4 + Math.random() * 2.2;
      const x = Math.cos(angle) * radius;
      const y = (Math.random() - 0.5) * 3;
      const z = Math.sin(angle) * radius - 0.5;

      beanMesh.position.set(x, y, z);
      beanMesh.rotation.set(
        Math.random() * Math.PI * 2,
        Math.random() * Math.PI * 2,
        Math.random() * Math.PI * 2
      );
      beanMesh.scale.setScalar(0.7 + Math.random() * 0.6);
      beanMesh.castShadow = true;
      beansGroup.add(beanMesh);

      beansData.push({
        mesh: beanMesh,
        origPos: new THREE.Vector3(x, y, z),
        rotSpeed: new THREE.Vector3(
          (Math.random() - 0.5) * 0.015,
          (Math.random() - 0.5) * 0.015,
          (Math.random() - 0.5) * 0.015
        ),
        floatSpeed: 0.8 + Math.random() * 0.6,
        orbitRadius: radius,
        orbitAngle: angle,
      });
    }

    // --- 4. Ambient Golden Aroma Dust / Embers ---
    const amberCount = 60;
    const amberGeo = new THREE.BufferGeometry();
    const amberPos = new Float32Array(amberCount * 3);
    for (let i = 0; i < amberCount; i++) {
      amberPos[i * 3] = (Math.random() - 0.5) * 10;
      amberPos[i * 3 + 1] = (Math.random() - 0.5) * 6;
      amberPos[i * 3 + 2] = (Math.random() - 0.5) * 6;
    }
    amberGeo.setAttribute("position", new THREE.BufferAttribute(amberPos, 3));
    const amberMat = new THREE.PointsMaterial({
      size: 0.04,
      color: 0xc59d5f,
      transparent: true,
      opacity: 0.45,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const amberParticles = new THREE.Points(amberGeo, amberMat);
    scene.add(amberParticles);

    // ==========================================
    // INTERACTION & SCROLL CONTROLLER
    // ==========================================
    let mouseX = 0;
    let mouseY = 0;
    let targetMouseX = 0;
    let targetMouseY = 0;

    const handleMouseMove = (e: MouseEvent) => {
      targetMouseX = (e.clientX / window.innerWidth - 0.5) * 2;
      targetMouseY = (e.clientY / window.innerHeight - 0.5) * 2;
    };

    if (interactive && brandConfig.threeD.enableMouseParallax) {
      window.addEventListener("mousemove", handleMouseMove, { passive: true });
    }

    // Resize observer
    const handleResize = () => {
      if (!canvas) return;
      const width = canvas.clientWidth;
      const height = canvas.clientHeight;
      if (width === 0 || height === 0) return;

      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height, false);
    };

    const resizeObserver = new ResizeObserver(() => {
      handleResize();
    });
    resizeObserver.observe(canvas);

    // Animation Loop
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const renderLoop = () => {
      const elapsedTime = clock.getElapsedTime();

      // Smooth mouse lerp
      mouseX += (targetMouseX - mouseX) * 0.05;
      mouseY += (targetMouseY - mouseY) * 0.05;

      // Scroll progress detection (0 to 1)
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      const scrollPercent = docHeight > 0 ? Math.min(Math.max(window.scrollY / docHeight, 0), 1) : 0;

      // 1. Camera positioning linked to scroll
      // Sections progress:
      // 0.0 -> Hero (Front angled close-up)
      // 0.2 -> Section 1 Our Coffee (Panned right, camera shifts left)
      // 0.4 -> Section 2 Beans (Camera dives forward, rotating among beans)
      // 0.6 -> Section 3 Process (Camera pans diagonally)
      // 0.8 -> Section 4 Signature / Products (Elevated view)
      // 1.0 -> Experience / CTA (Grand pull back)
      const targetCamX = Math.sin(scrollPercent * Math.PI * 2.5) * 0.8 + mouseX * 0.25;
      const targetCamY = 0.7 - scrollPercent * 0.4 - mouseY * 0.2;
      const targetCamZ = 2.7 - Math.sin(scrollPercent * Math.PI) * 0.6;

      camera.position.x += (targetCamX - camera.position.x) * 0.06;
      camera.position.y += (targetCamY - camera.position.y) * 0.06;
      camera.position.z += (targetCamZ - camera.position.z) * 0.06;
      camera.lookAt(0, -0.1, 0);

      // 2. Hero Cup Subtle 3D floating & rotation
      heroGroup.position.y = Math.sin(elapsedTime * 1.2) * 0.03 - scrollPercent * 0.3;
      heroGroup.rotation.y = -0.3 + scrollPercent * 2.5 + mouseX * 0.15;
      heroGroup.rotation.x = 0.25 - scrollPercent * 0.2 + mouseY * 0.1;

      // 3. Steam animation loop
      const steamPosAttr = steamGeo.attributes.position as THREE.BufferAttribute;
      for (let i = 0; i < steamCount; i++) {
        const vel = steamVelocities[i];
        vel.age += 1;
        let y = steamPosAttr.getY(i) + vel.y;
        let x = steamPosAttr.getX(i) + vel.x + Math.sin(elapsedTime * 2 + i) * 0.001;
        let z = steamPosAttr.getZ(i) + vel.z;

        if (vel.age > vel.maxAge) {
          vel.age = 0;
          x = (Math.random() - 0.5) * 0.35;
          y = 0.35;
          z = (Math.random() - 0.5) * 0.35;
        }

        steamPosAttr.setXYZ(i, x, y, z);
      }
      steamPosAttr.needsUpdate = true;

      // 4. Floating beans motion
      beansData.forEach((item, index) => {
        item.orbitAngle += 0.002 * item.floatSpeed;
        const x = Math.cos(item.orbitAngle) * item.orbitRadius;
        const z = Math.sin(item.orbitAngle) * item.orbitRadius - 0.5;
        const y = item.origPos.y + Math.sin(elapsedTime * item.floatSpeed + index) * 0.15;

        item.mesh.position.set(x, y, z);
        item.mesh.rotation.x += item.rotSpeed.x;
        item.mesh.rotation.y += item.rotSpeed.y;
        item.mesh.rotation.z += item.rotSpeed.z;
      });

      // 5. Golden aroma dust subtle drift
      amberParticles.rotation.y = elapsedTime * 0.02;
      amberParticles.position.y = Math.sin(elapsedTime * 0.5) * 0.1;

      renderer.render(scene, camera);
      animationFrameId = requestAnimationFrame(renderLoop);
    };

    renderLoop();

    return () => {
      cancelAnimationFrame(animationFrameId);
      if (interactive) {
        window.removeEventListener("mousemove", handleMouseMove);
      }
      resizeObserver.disconnect();
      renderer.dispose();
      scene.clear();
    };
  }, [interactive]);

  if (!isWebGLAvailable) {
    return (
      <div className={`relative overflow-hidden ${className}`}>
        <img
          src={brandConfig.images.heroCoffee}
          alt="Aurelia Coffee Presentation"
          className="w-full h-full object-cover opacity-60"
          referrerPolicy="no-referrer"
        />
      </div>
    );
  }

  return (
    <canvas
      ref={canvasRef}
      className={`w-full h-full block pointer-events-none ${className}`}
      aria-hidden="true"
    />
  );
};
