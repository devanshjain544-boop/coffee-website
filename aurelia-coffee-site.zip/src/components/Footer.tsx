import React, { useState } from "react";
import { brandConfig } from "../config/brandConfig";
import { ArrowUp, ArrowRight, Check, Download } from "lucide-react";

export const Footer: React.FC = () => {
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setTimeout(() => setSubscribed(false), 3000);
      setEmail("");
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="relative bg-[#0a0807] border-t border-[#261b14] pt-24 pb-16 px-6 md:px-12 text-[#a8947f]">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 pb-16 border-b border-[#201610]">
          {/* Brand Info (5 cols) */}
          <div className="md:col-span-5 flex flex-col justify-between">
            <div>
              <span className="font-serif-luxury text-3xl md:text-4xl text-[#f4eee6] tracking-[0.2em] font-light block mb-3">
                {brandConfig.brand.name}
              </span>
              <p className="font-serif text-lg text-[#d6c7b2] italic mb-6">
                "{brandConfig.brand.tagline}"
              </p>
              <p className="text-xs font-light text-[#8a7563] leading-relaxed max-w-sm">
                Dedicated to restoring quiet reverence to the morning brew. Single-estate elevations, ethical direct trade, and precision roasting.
              </p>
            </div>

            <div className="mt-8 pt-6 border-t border-[#1a120d] text-xs font-mono text-[#8a7563]">
              <p>{brandConfig.brand.origin}</p>
              <p>{brandConfig.brand.address}</p>
              <p className="text-[#c59d5f] mt-1">{brandConfig.brand.contactEmail}</p>
            </div>
          </div>

          {/* Quick Links (3 cols) */}
          <div className="md:col-span-3">
            <h4 className="text-xs font-mono uppercase tracking-[0.25em] text-[#c59d5f] mb-6">
              NAVIGATION
            </h4>
            <ul className="space-y-3 text-xs uppercase tracking-[0.2em] text-[#d6c7b2]">
              <li>
                <a href="#hero-section" className="hover:text-[#c59d5f] transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="#our-coffee" className="hover:text-[#c59d5f] transition-colors">
                  Our Coffee
                </a>
              </li>
              <li>
                <a href="#the-beans" className="hover:text-[#c59d5f] transition-colors">
                  The Beans
                </a>
              </li>
              <li>
                <a href="#process-section" className="hover:text-[#c59d5f] transition-colors">
                  Bean to Cup
                </a>
              </li>
              <li>
                <a href="#signature-section" className="hover:text-[#c59d5f] transition-colors">
                  Signature Blend
                </a>
              </li>
              <li>
                <a href="#collection-section" className="hover:text-[#c59d5f] transition-colors">
                  Coffee Collection
                </a>
              </li>
              <li>
                <a href="#story-section" className="hover:text-[#c59d5f] transition-colors">
                  Our Story
                </a>
              </li>
            </ul>
          </div>

          {/* Newsletter / Private Reserve Dispatch (4 cols) */}
          <div className="md:col-span-4">
            <h4 className="text-xs font-mono uppercase tracking-[0.25em] text-[#c59d5f] mb-6">
              THE ROASTER'S DISPATCH
            </h4>
            <p className="text-xs font-light text-[#8a7563] leading-relaxed mb-6">
              Receive private invitations to limited microlot releases, harvest notes, and brewing masterclasses.
            </p>

            <form onSubmit={handleSubscribe} className="space-y-3">
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Your email address"
                  className="w-full px-4 py-3.5 bg-[#140f0c] border border-[#2e2118] text-xs text-[#f4eee6] placeholder-[#665243] focus:outline-none focus:border-[#c59d5f]"
                  required
                />
                <button
                  type="submit"
                  aria-label="Subscribe"
                  className="absolute right-1.5 top-1.5 bottom-1.5 px-4 bg-[#c59d5f] hover:bg-[#dfbc84] text-[#0f0c0a] text-xs font-semibold flex items-center justify-center transition-colors"
                >
                  {subscribed ? <Check className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
                </button>
              </div>
              {subscribed && (
                <p className="text-[11px] text-emerald-400 font-mono">
                  Welcome to the Aurelia reserve list.
                </p>
              )}
            </form>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-light text-[#665243]">
          <p>{brandConfig.content.footer.copyright}</p>
          <a
            href="/aurelia-coffee-site.zip"
            download="aurelia-coffee-site.zip"
            className="inline-flex items-center gap-2 px-3 py-1 bg-[#16100c] hover:bg-[#251b14] border border-[#38271c] hover:border-[#c59d5f] text-[#c59d5f] text-[10px] font-mono uppercase tracking-widest transition-colors rounded-sm"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Site ZIP (.zip)</span>
          </a>
          <button
            onClick={scrollToTop}
            className="flex items-center gap-2 text-[#a8947f] hover:text-[#c59d5f] transition-colors uppercase text-[10px] tracking-widest font-mono"
          >
            <span>BACK TO TOP</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </footer>
  );
};
