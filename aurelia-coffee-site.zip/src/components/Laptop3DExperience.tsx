import React, { useState, useEffect, useRef } from "react";
import { CoffeeExperience3D } from "./CoffeeExperience3D";
import { brandConfig } from "../config/brandConfig";
import {
  ChevronDown,
  ChevronUp,
  Volume2,
  VolumeX,
  Sparkles,
  ArrowRight,
  ShoppingBag,
  RotateCcw,
  Coffee,
  Compass,
  Zap,
} from "lucide-react";
import { tapticEngine } from "../utils/tapticEngine";

interface Laptop3DExperienceProps {
  onEnterStore: () => void;
}

export const Laptop3DExperience: React.FC<Laptop3DExperienceProps> = ({
  onEnterStore,
}) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [isMuted, setIsMuted] = useState(true);
  const [isLaptopTiltActive, setIsLaptopTiltActive] = useState(true);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);

  // Audio tone generator for luxury interactive feedback
  const playChime = (freq = 440) => {
    if (isMuted) return;
    try {
      const AudioContext = window.AudioContext || (window as unknown as { webkitAudioContext: typeof window.AudioContext }).webkitAudioContext;
      if (!AudioContext) return;
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(0.04, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.6);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.6);
    } catch {
      // Audio context might be restricted before gesture
    }
  };

  // 5 Chapter Slides mirroring the viral interactive scroll experience
  const chapters = [
    {
      id: "heritage",
      eyebrow: "01 • ATELIER DE CAFÉ",
      title: "The Golden Standard of Specialty Coffee",
      tagline: "Where volcanic soils meet meticulous Swiss precision.",
      accent: "#c59d5f",
      badge: "SINGLE ORIGIN • 1850M",
      stat: "100%",
      statLabel: "Shade Grown Arabica",
    },
    {
      id: "beans",
      eyebrow: "02 • THE RAW ESSENCE",
      title: "Micro-Lot Heirloom Typica & Geisha",
      tagline: "Hand-picked at peak crimson ripeness across high-altitude slopes.",
      accent: "#dfbc84",
      badge: "SCA SCORE 89.5+",
      stat: "Top 1%",
      statLabel: "Global Harvest",
    },
    {
      id: "extraction",
      eyebrow: "03 • SCIENTIFIC EXTRACTION",
      title: "Meticulous Thermal & Flow Profiling",
      tagline: "Slow extraction unwrapping layers of jasmine, bergamot & raw cacao.",
      accent: "#e5a65d",
      badge: "9bar PRECISION",
      stat: "27s",
      statLabel: "Golden Ratio Pour",
    },
    {
      id: "ritual",
      eyebrow: "04 • THE DAILY CEREMONY",
      title: "Silky Microfoam & Rosetta Artistry",
      tagline: "Crafted not merely to awaken, but to inspire your greatest work.",
      accent: "#f4eee6",
      badge: "CRAFTED IN DUBAI & ZÜRICH",
      stat: "65°C",
      statLabel: "Velvet Texture",
    },
    {
      id: "signature",
      eyebrow: "05 • PRIVATE RESERVE",
      title: "Aurelia Signature Blend No. 1",
      tagline: "Dark chocolate, roasted hazelnut, dried fig, and Tahitian vanilla.",
      accent: "#c59d5f",
      badge: "LIMITED HARVEST 2026",
      stat: "250g",
      statLabel: "Numbered Tins",
    },
  ];

  // Mouse tilt listener for the laptop chassis
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const x = (e.clientX / window.innerWidth - 0.5) * 2;
      const y = (e.clientY / window.innerHeight - 0.5) * 2;
      setMousePos({ x, y });
    };

    window.addEventListener("mousemove", handleMouseMove, { passive: true });
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  // Wheel scroll to flip 3D steps smoothly
  const isScrollingRef = useRef(false);
  const handleWheel = (e: React.WheelEvent) => {
    if (isScrollingRef.current) return;
    if (Math.abs(e.deltaY) > 35) {
      isScrollingRef.current = true;
      if (e.deltaY > 0) {
        goToNext();
      } else {
        goToPrev();
      }
      setTimeout(() => {
        isScrollingRef.current = false;
      }, 750);
    }
  };

  const goToNext = () => {
    tapticEngine.trigger("medium");
    setCurrentStep((prev) => {
      const next = Math.min(chapters.length - 1, prev + 1);
      playChime(350 + next * 80);
      return next;
    });
  };

  const goToPrev = () => {
    tapticEngine.trigger("light");
    setCurrentStep((prev) => {
      const next = Math.max(0, prev - 1);
      playChime(350 + next * 80);
      return next;
    });
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowDown" || e.key === "ArrowRight" || e.key === "PageDown") {
        e.preventDefault();
        goToNext();
      } else if (e.key === "ArrowUp" || e.key === "ArrowLeft" || e.key === "PageUp") {
        e.preventDefault();
        goToPrev();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  const current = chapters[currentStep];

  // Calculate realistic laptop 3D rotation based on mouse
  const laptopRotX = isLaptopTiltActive ? 8 + mousePos.y * 5 : 8;
  const laptopRotY = isLaptopTiltActive ? -mousePos.x * 7 : 0;

  return (
    <div
      ref={containerRef}
      onWheel={handleWheel}
      className="relative w-full h-screen bg-[#080605] overflow-hidden select-none flex flex-col justify-between items-center"
      style={{ perspective: "1800px" }}
    >
      {/* Background Ambience / Studio Lighting */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_35%,#261910_0%,#0f0b08_55%,#040302_100%)] pointer-events-none" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[900px] h-[450px] bg-[#c59d5f]/10 rounded-full blur-[140px] pointer-events-none" />

      {/* Top Floating Luxury Header */}
      <header className="w-full max-w-7xl mx-auto px-6 py-4 flex items-center justify-between z-30">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-[#1a130f] border border-[#c59d5f]/40 flex items-center justify-center shadow-lg shadow-[#c59d5f]/10">
            <Sparkles className="w-4 h-4 text-[#c59d5f]" />
          </div>
          <div>
            <span className="font-serif-luxury text-lg tracking-[0.2em] text-[#f4eee6] block font-light">
              {brandConfig.brand.name}
            </span>
            <span className="text-[9px] uppercase tracking-[0.25em] text-[#8a7563] font-mono">
              3D Interactive Experience
            </span>
          </div>
        </div>

        {/* Center Progress Indicators */}
        <div className="hidden md:flex items-center gap-2 px-4 py-1.5 bg-[#140f0c]/80 backdrop-blur-md rounded-full border border-[#2b1f17]">
          {chapters.map((chap, idx) => (
            <button
              key={chap.id}
              onClick={() => {
                tapticEngine.trigger("light");
                setCurrentStep(idx);
                playChime(350 + idx * 80);
              }}
              className={`group flex items-center gap-2 px-2.5 py-1 rounded-full text-[10px] font-mono transition-all duration-300 ${
                currentStep === idx
                  ? "bg-[#c59d5f] text-[#0f0c0a] font-bold shadow-md shadow-[#c59d5f]/30"
                  : "text-[#8a7563] hover:text-[#f4eee6]"
              }`}
            >
              <span>0{idx + 1}</span>
              {currentStep === idx && (
                <span className="text-[9px] uppercase tracking-wider font-sans">
                  {chap.id}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Right Controls */}
        <div className="flex items-center gap-3">
          {/* Sound Toggle */}
          <button
            onClick={() => {
              setIsMuted(!isMuted);
              playChime(500);
            }}
            title={isMuted ? "Unmute Audio Chimes" : "Mute Sound"}
            className="p-2 rounded-full bg-[#16100c] border border-[#2e2118] text-[#c59d5f] hover:border-[#c59d5f] transition-all"
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>

          {/* Direct Button to Full Shop */}
          <button
            onClick={onEnterStore}
            className="flex items-center gap-2 px-5 py-2 bg-[#c59d5f] hover:bg-[#dfbc84] text-[#0f0c0a] text-xs font-semibold uppercase tracking-[0.2em] shadow-lg shadow-[#c59d5f]/20 transition-all hover:scale-105"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Enter Full Store</span>
          </button>
        </div>
      </header>

      {/* Main 3D Laptop Showcase Viewport */}
      <main className="relative flex-1 w-full flex items-center justify-center p-2 sm:p-6 overflow-hidden">
        {/* The 3D Laptop Assembly */}
        <div
          className="relative transition-transform duration-500 ease-out origin-center"
          style={{
            transform: `rotateX(${laptopRotX}deg) rotateY(${laptopRotY}deg) scale(0.92)`,
            transformStyle: "preserve-3d",
          }}
        >
          {/* LAPTOP SCREEN LID (Opening Sequence Animation) */}
          <div
            className="w-[94vw] max-w-[1180px] h-[68vh] min-h-[460px] max-h-[720px] bg-[#140e0b] rounded-[22px] p-3 sm:p-4 shadow-[0_50px_100px_-20px_rgba(0,0,0,0.95),0_30px_70px_-20px_rgba(197,157,95,0.2)] border-[3px] border-[#38281e] relative flex flex-col overflow-hidden animate-laptop-lid"
            style={{ transformStyle: "preserve-3d" }}
          >
            {/* Top Display Bezel: Camera notch + Mac dots */}
            <div className="w-full flex items-center justify-between px-3 pb-2 pt-0.5 select-none z-20">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-[#ff5f56]" />
                <span className="w-2.5 h-2.5 rounded-full bg-[#ffbd2e]" />
                <span className="w-2.5 h-2.5 rounded-full bg-[#27c93f]" />
              </div>

              {/* Minimal Web Address Bar (Mirroring Viral Demo) */}
              <div className="flex items-center gap-2 px-4 py-0.5 bg-[#090705] rounded-full border border-[#2b1e16] text-[10px] font-mono text-[#8a7563]">
                <span className="text-emerald-400 font-bold">🔒</span>
                <span>aureliacoffee.work.gd</span>
              </div>

              <div className="flex items-center gap-2 text-[10px] font-mono text-[#c59d5f]">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>60 FPS 3D</span>
              </div>
            </div>

            {/* SCREEN INNER STAGE (WebGl 3D + Kinetic Typography Overlay) */}
            <div className="relative flex-1 w-full rounded-[14px] bg-gradient-to-b from-[#120d09] to-[#0a0705] overflow-hidden border border-[#281b13]">
              {/* 1. Real-time 3D WebGL Scene */}
              <div className="absolute inset-0 z-0">
                <CoffeeExperience3D currentStep={currentStep} />
              </div>

              {/* 2. Ambient Lighting Glow inside the Screen */}
              <div
                className="absolute inset-0 pointer-events-none transition-colors duration-1000"
                style={{
                  background: `radial-gradient(circle at 50% 50%, ${current.accent}15 0%, transparent 70%)`,
                }}
              />

              {/* 3. High-Fashion Editorial Typography Overlay (Viral Showcase Style) */}
              <div className="relative z-10 w-full h-full flex flex-col justify-between p-6 sm:p-10 pointer-events-none">
                {/* Top Chapter Metadata (Staggered cinematic entrance coordinated with laptop lid) */}
                <div className="flex items-start justify-between">
                  <div key={`title-${currentStep}`} className="animate-cinematic-up" style={{ animationDelay: "300ms" }}>
                    <span className="inline-block px-3 py-1 bg-[#1a120c]/80 border border-[#c59d5f]/40 rounded-full text-[10px] uppercase font-mono tracking-[0.25em] text-[#c59d5f] backdrop-blur-md mb-2">
                      {current.eyebrow}
                    </span>
                    <h2 className="font-serif-luxury text-2xl sm:text-4xl md:text-5xl font-light text-[#f4eee6] tracking-tight max-w-xl leading-tight">
                      {current.title}
                    </h2>
                    <p className="text-xs sm:text-sm text-[#d6c7b2] font-light max-w-md mt-2 tracking-wide font-sans">
                      {current.tagline}
                    </p>
                  </div>

                  {/* Top Right Luxury Badge */}
                  <div key={`badge-${currentStep}`} className="hidden sm:flex flex-col items-end text-right animate-cinematic-up" style={{ animationDelay: "450ms" }}>
                    <span className="text-[10px] font-mono tracking-[0.3em] uppercase text-[#8a7563]">
                      ORIGIN
                    </span>
                    <span className="text-xs font-mono text-[#c59d5f] font-semibold tracking-wider">
                      {current.badge}
                    </span>
                  </div>
                </div>

                {/* Center / Bottom Cinematic Kinetic Callouts */}
                <div className="flex items-end justify-between">
                  {/* Left: Dynamic Key Stat */}
                  <div
                    key={`stat-${currentStep}`}
                    className="bg-[#140e0a]/80 backdrop-blur-md p-3 sm:p-4 rounded-xl border border-[#2b1f17] flex items-center gap-4 animate-cinematic-up"
                    style={{ animationDelay: "600ms" }}
                  >
                    <div className="text-2xl sm:text-4xl font-serif-luxury font-light text-[#c59d5f]">
                      {current.stat}
                    </div>
                    <div className="text-left">
                      <span className="block text-[9px] uppercase tracking-[0.2em] font-mono text-[#8a7563]">
                        Specification
                      </span>
                      <span className="text-xs text-[#f4eee6] font-medium font-sans">
                        {current.statLabel}
                      </span>
                    </div>
                  </div>

                  {/* Right: Interactive CTA to Explore Blend */}
                  <div className="pointer-events-auto flex items-center gap-3 animate-cinematic-up" style={{ animationDelay: "750ms" }}>
                    <button
                      onClick={goToNext}
                      className="px-5 py-2.5 bg-[#c59d5f] hover:bg-[#dfbc84] text-[#0f0c0a] text-xs uppercase font-semibold tracking-[0.2em] rounded-none transition-all shadow-lg flex items-center gap-2 group"
                    >
                      <span>{currentStep === chapters.length - 1 ? "ENTER SHOP" : "NEXT CHAPTER"}</span>
                      <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Glossy Screen Glare Reflection */}
              <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/[0.03] to-transparent pointer-events-none" />
            </div>
          </div>

          {/* 3D LAPTOP KEYBOARD BASE DECK */}
          <div
            className="w-[98vw] max-w-[1240px] h-14 bg-gradient-to-b from-[#2b1f18] via-[#1c140f] to-[#0c0806] rounded-b-[24px] mx-auto -mt-2 border-t border-[#4d382a] shadow-[0_45px_90px_rgba(0,0,0,0.95)] flex items-center justify-center relative select-none animate-laptop-deck"
            style={{
              transform: "rotateX(72deg) translateZ(-22px)",
              transformOrigin: "top center",
            }}
          >
            {/* Center thumb notch */}
            <div className="w-32 h-2 bg-[#120c08] rounded-b-md border-b border-[#3b2a1e]" />
          </div>
        </div>
      </main>

      {/* Bottom Control Bar & Scroll Navigation */}
      <footer className="w-full max-w-6xl mx-auto px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-4 z-30 border-t border-[#1f1610] bg-[#080605]/90 backdrop-blur-md">
        {/* Left: Scroll / Key Hint */}
        <div className="flex items-center gap-3 text-[11px] font-mono text-[#8a7563]">
          <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-[#140e0a] border border-[#2b1e16] rounded text-[#c59d5f]">
            <ChevronDown className="w-3 h-3" /> Scroll
          </span>
          <span>Scroll down or use buttons to rotate the 3D coffee world</span>
        </div>

        {/* Center: Slide Step Arrows */}
        <div className="flex items-center gap-2">
          <button
            onClick={goToPrev}
            disabled={currentStep === 0}
            className="p-2 bg-[#17100b] hover:bg-[#261a12] disabled:opacity-30 disabled:hover:bg-[#17100b] border border-[#2e2017] rounded-full text-[#c59d5f] transition-all"
            aria-label="Previous 3D Chapter"
          >
            <ChevronUp className="w-4 h-4" />
          </button>
          <span className="text-xs font-mono text-[#c59d5f] px-2">
            0{currentStep + 1} / 0{chapters.length}
          </span>
          <button
            onClick={goToNext}
            disabled={currentStep === chapters.length - 1}
            className="p-2 bg-[#17100b] hover:bg-[#261a12] disabled:opacity-30 disabled:hover:bg-[#17100b] border border-[#2e2017] rounded-full text-[#c59d5f] transition-all"
            aria-label="Next 3D Chapter"
          >
            <ChevronDown className="w-4 h-4" />
          </button>
        </div>

        {/* Right: Full Store Toggle */}
        <button
          onClick={onEnterStore}
          className="text-xs font-mono text-[#c59d5f] hover:text-[#f4eee6] tracking-[0.2em] uppercase underline underline-offset-4 transition-colors"
        >
          Skip 3D Intro &rarr;
        </button>
      </footer>
    </div>
  );
};
