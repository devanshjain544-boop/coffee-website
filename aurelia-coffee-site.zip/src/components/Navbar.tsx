import React, { useState, useEffect } from "react";
import { brandConfig } from "../config/brandConfig";
import { ShoppingBag, Menu, X, Monitor, Eye, Sparkles, Download } from "lucide-react";

interface NavbarProps {
  isPerspectiveMode: boolean;
  onTogglePerspective: () => void;
  onEnter3DExperience?: () => void;
  cartCount: number;
  onOpenCart: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  isPerspectiveMode,
  onTogglePerspective,
  onEnter3DExperience,
  cartCount,
  onOpenCart,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const navOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - navOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      });
    }
  };

  return (
    <header
      id="main-navbar"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled
          ? "bg-[#0f0c0a]/90 backdrop-blur-md border-b border-[#33241b]/60 py-4 shadow-2xl"
          : "bg-transparent py-6 border-b border-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex items-center justify-between">
        {/* Left: Brand Name */}
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className="text-left group focus:outline-none"
          id="nav-brand-logo"
        >
          <span className="font-serif-luxury text-xl md:text-2xl font-light tracking-[0.25em] text-[#f4eee6] group-hover:text-[#c59d5f] transition-colors duration-300">
            {brandConfig.brand.name}
          </span>
          <span className="block text-[9px] uppercase tracking-[0.3em] text-[#a8947f] font-sans">
            Atelier de Café
          </span>
        </button>

        {/* Center: Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-8 text-xs uppercase tracking-[0.2em] text-[#d6c7b2] font-medium" id="desktop-nav-links">
          <button
            onClick={() => scrollToSection("hero-section")}
            className="hover:text-[#c59d5f] transition-colors py-1 relative group focus:outline-none"
            id="nav-link-home"
          >
            HOME
            <span className="absolute bottom-0 left-0 w-0 h-[1px] bg-[#c59d5f] group-hover:w-full transition-all duration-300"></span>
          </button>
          <button
            onClick={() => scrollToSection("our-coffee")}
            className="hover:text-[#c59d5f] transition-colors py-1 relative group focus:outline-none"
            id="nav-link-coffee"
          >
            COFFEE
            <span className="absolute bottom-0 left-0 w-0 h-[1px] bg-[#c59d5f] group-hover:w-full transition-all duration-300"></span>
          </button>
          <button
            onClick={() => scrollToSection("the-beans")}
            className="hover:text-[#c59d5f] transition-colors py-1 relative group focus:outline-none"
            id="nav-link-beans"
          >
            THE BEANS
            <span className="absolute bottom-0 left-0 w-0 h-[1px] bg-[#c59d5f] group-hover:w-full transition-all duration-300"></span>
          </button>
          <button
            onClick={() => scrollToSection("process-section")}
            className="hover:text-[#c59d5f] transition-colors py-1 relative group focus:outline-none"
            id="nav-link-process"
          >
            PROCESS
            <span className="absolute bottom-0 left-0 w-0 h-[1px] bg-[#c59d5f] group-hover:w-full transition-all duration-300"></span>
          </button>
          <button
            onClick={() => scrollToSection("collection-section")}
            className="hover:text-[#c59d5f] transition-colors py-1 relative group focus:outline-none"
            id="nav-link-collection"
          >
            COLLECTION
            <span className="absolute bottom-0 left-0 w-0 h-[1px] bg-[#c59d5f] group-hover:w-full transition-all duration-300"></span>
          </button>
          <button
            onClick={() => scrollToSection("story-section")}
            className="hover:text-[#c59d5f] transition-colors py-1 relative group focus:outline-none"
            id="nav-link-story"
          >
            STORY
            <span className="absolute bottom-0 left-0 w-0 h-[1px] bg-[#c59d5f] group-hover:w-full transition-all duration-300"></span>
          </button>
        </nav>

        {/* Right: 3D Laptop Experience, Perspective Toggle, Cart, and Shop Now CTA */}
        <div className="flex items-center gap-2 sm:gap-3 md:gap-4">
          {/* 3D Laptop Scroll Experience Launcher */}
          {onEnter3DExperience && (
            <button
              onClick={onEnter3DExperience}
              title="Launch 3D Laptop Scroll Experience"
              className="flex items-center gap-2 px-3 py-1.5 rounded-full text-[11px] uppercase tracking-wider font-semibold border border-[#c59d5f] bg-[#c59d5f]/15 hover:bg-[#c59d5f] text-[#c59d5f] hover:text-[#0f0c0a] transition-all duration-300 shadow-md shadow-[#c59d5f]/10 focus:outline-none"
              id="laptop-3d-experience-btn"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#c59d5f] group-hover:text-[#0f0c0a]" />
              <span className="hidden sm:inline">3D Laptop Scroll</span>
              <span className="sm:hidden">3D</span>
            </button>
          )}

          {/* Agency 3D Angled Device Showcase Mode Toggle */}
          <button
            onClick={onTogglePerspective}
            title={isPerspectiveMode ? "Switch to Fullscreen Website" : "View Agency 3D Laptop Perspective Showcase"}
            className={`hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full text-[11px] uppercase tracking-wider font-semibold border transition-all duration-300 focus:outline-none ${
              isPerspectiveMode
                ? "bg-[#c59d5f] text-[#0f0c0a] border-[#c59d5f] shadow-lg shadow-[#c59d5f]/20"
                : "bg-[#1f1814]/80 text-[#d6c7b2] border-[#443328] hover:border-[#c59d5f] hover:text-[#f4eee6]"
            }`}
            id="perspective-mode-toggle"
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>{isPerspectiveMode ? "Exit 3D View" : "Device View"}</span>
          </button>

          {/* Direct Download ZIP Button */}
          <a
            href="/aurelia-coffee-site.zip"
            download="aurelia-coffee-site.zip"
            title="Download full website ZIP (Source Code & Assets)"
            className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[11px] uppercase tracking-wider font-semibold border border-[#554032] bg-[#1a1410] hover:border-[#c59d5f] text-[#d6c7b2] hover:text-[#f4eee6] transition-all duration-300"
            id="download-zip-nav-btn"
          >
            <Download className="w-3.5 h-3.5 text-[#c59d5f]" />
            <span>Download ZIP</span>
          </a>

          {/* Cart Icon */}
          <button
            onClick={onOpenCart}
            aria-label="View Shopping Cart"
            className="relative p-2 text-[#d6c7b2] hover:text-[#c59d5f] transition-colors focus:outline-none"
            id="nav-cart-btn"
          >
            <ShoppingBag className="w-5 h-5 stroke-[1.5]" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-[#c59d5f] text-[#0f0c0a] text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>

          {/* Shop Now Primary Button */}
          <button
            onClick={() => scrollToSection("collection-section")}
            className="hidden sm:inline-flex items-center justify-center px-5 py-2.5 text-xs font-semibold tracking-[0.2em] uppercase text-[#0f0c0a] bg-[#c59d5f] hover:bg-[#dfbc84] transition-all duration-300 shadow-md hover:shadow-lg hover:shadow-[#c59d5f]/20 focus:outline-none rounded-none"
            id="nav-shop-now-btn"
          >
            SHOP NOW
          </button>

          {/* Mobile Hamburger Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle Menu"
            className="lg:hidden p-2 text-[#f4eee6] hover:text-[#c59d5f] transition-colors focus:outline-none"
            id="mobile-nav-toggle"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#140f0c]/98 border-b border-[#33241b] px-6 py-8 backdrop-blur-xl animate-in fade-in slide-in-from-top-4 duration-300">
          <nav className="flex flex-col gap-6 text-sm uppercase tracking-[0.25em] text-[#d6c7b2]">
            <button
              onClick={() => scrollToSection("hero-section")}
              className="text-left py-2 hover:text-[#c59d5f] transition-colors"
            >
              HOME
            </button>
            <button
              onClick={() => scrollToSection("our-coffee")}
              className="text-left py-2 hover:text-[#c59d5f] transition-colors"
            >
              OUR COFFEE
            </button>
            <button
              onClick={() => scrollToSection("the-beans")}
              className="text-left py-2 hover:text-[#c59d5f] transition-colors"
            >
              THE BEANS
            </button>
            <button
              onClick={() => scrollToSection("process-section")}
              className="text-left py-2 hover:text-[#c59d5f] transition-colors"
            >
              FROM BEAN TO CUP
            </button>
            <button
              onClick={() => scrollToSection("collection-section")}
              className="text-left py-2 hover:text-[#c59d5f] transition-colors"
            >
              COFFEE COLLECTION
            </button>
            <button
              onClick={() => scrollToSection("story-section")}
              className="text-left py-2 hover:text-[#c59d5f] transition-colors"
            >
              OUR STORY
            </button>
            <div className="pt-4 border-t border-[#33241b] flex flex-col gap-3">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onTogglePerspective();
                }}
                className="flex items-center justify-center gap-2 py-3 text-xs tracking-[0.2em] uppercase border border-[#c59d5f] text-[#c59d5f]"
              >
                <Monitor className="w-4 h-4" />
                {isPerspectiveMode ? "Exit 3D Showcase" : "3D Device View"}
              </button>
              <button
                onClick={() => scrollToSection("collection-section")}
                className="py-3 text-xs tracking-[0.2em] uppercase bg-[#c59d5f] text-[#0f0c0a] font-bold text-center"
              >
                SHOP NOW
              </button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};
