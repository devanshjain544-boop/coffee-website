import React, { useState, useEffect, useRef } from "react";
import { Monitor, X, RotateCcw, Sparkles, Compass, Maximize2 } from "lucide-react";

interface PerspectiveShowcaseProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode;
}

type AnglePreset = "cinematic" | "isometric" | "topTilt" | "interactive";

export const PerspectiveShowcase: React.FC<PerspectiveShowcaseProps> = ({
  isOpen,
  onClose,
  children,
}) => {
  const [preset, setPreset] = useState<AnglePreset>("cinematic");
  const [mouseTilt, setMouseTilt] = useState({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);

  const handlePresetSelect = (newPreset: AnglePreset) => {
    setPreset(newPreset);
  };

  useEffect(() => {
    if (!isOpen) return;

    const handleMouseMove = (e: MouseEvent) => {
      if (preset !== "interactive") return;
      const x = (e.clientX / window.innerWidth - 0.5) * 2;
      const y = (e.clientY / window.innerHeight - 0.5) * 2;
      setMouseTilt({ x, y });
    };

    window.addEventListener("mousemove", handleMouseMove, { passive: true });
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, [isOpen, preset]);

  if (!isOpen) return null;

  // Compute 3D rotation styling based on preset
  let transformStyle = "";
  if (preset === "cinematic") {
    // Exact angled laptop presentation from high-end agency showcases
    transformStyle = "rotateX(14deg) rotateY(-12deg) rotateZ(3deg) scale(0.88)";
  } else if (preset === "isometric") {
    transformStyle = "rotateX(22deg) rotateY(-20deg) rotateZ(8deg) scale(0.84)";
  } else if (preset === "topTilt") {
    transformStyle = "rotateX(8deg) rotateY(-4deg) rotateZ(1deg) scale(0.92)";
  } else if (preset === "interactive") {
    const rx = 12 + mouseTilt.y * 8;
    const ry = -10 + mouseTilt.x * 12;
    const rz = 2 + mouseTilt.x * 2;
    transformStyle = `rotateX(${rx}deg) rotateY(${ry}deg) rotateZ(${rz}deg) scale(0.88)`;
  }

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-[100] bg-[#050403] flex flex-col items-center justify-between overflow-hidden select-none"
    >
      {/* Top Floating Control Bar */}
      <div className="w-full max-w-6xl mx-auto px-6 py-4 flex items-center justify-between z-50 border-b border-[#221812]/80 bg-[#0c0907]/90 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1 bg-[#1f1712] border border-[#3d2b1f] rounded-full">
            <Sparkles className="w-3.5 h-3.5 text-[#c59d5f]" />
            <span className="text-[10px] font-mono uppercase tracking-[0.25em] text-[#d6c7b2]">
              AGENCY PRESENTATION • 3D PERSPECTIVE VIEW
            </span>
          </div>
        </div>

        {/* Preset Angle Switcher */}
        <div className="hidden sm:flex items-center gap-2 bg-[#140f0c] p-1 border border-[#2a1e16] rounded-full">
          <button
            onClick={() => handlePresetSelect("cinematic")}
            className={`px-3 py-1 rounded-full text-[10px] uppercase font-mono tracking-wider transition-all ${
              preset === "cinematic"
                ? "bg-[#c59d5f] text-[#0f0c0a] font-bold"
                : "text-[#a8947f] hover:text-[#f4eee6]"
            }`}
          >
            Cinematic 3D
          </button>
          <button
            onClick={() => handlePresetSelect("isometric")}
            className={`px-3 py-1 rounded-full text-[10px] uppercase font-mono tracking-wider transition-all ${
              preset === "isometric"
                ? "bg-[#c59d5f] text-[#0f0c0a] font-bold"
                : "text-[#a8947f] hover:text-[#f4eee6]"
            }`}
          >
            Isometric
          </button>
          <button
            onClick={() => handlePresetSelect("topTilt")}
            className={`px-3 py-1 rounded-full text-[10px] uppercase font-mono tracking-wider transition-all ${
              preset === "topTilt"
                ? "bg-[#c59d5f] text-[#0f0c0a] font-bold"
                : "text-[#a8947f] hover:text-[#f4eee6]"
            }`}
          >
            Subtle Tilt
          </button>
          <button
            onClick={() => handlePresetSelect("interactive")}
            className={`px-3 py-1 rounded-full text-[10px] uppercase font-mono tracking-wider transition-all flex items-center gap-1.5 ${
              preset === "interactive"
                ? "bg-[#c59d5f] text-[#0f0c0a] font-bold"
                : "text-[#a8947f] hover:text-[#f4eee6]"
            }`}
          >
            <Compass className="w-3 h-3" />
            Mouse Parallax
          </button>
        </div>

        {/* Exit to Fullscreen */}
        <button
          onClick={onClose}
          className="flex items-center gap-2 px-4 py-2 bg-[#c59d5f] hover:bg-[#dfbc84] text-[#0f0c0a] text-xs uppercase tracking-[0.2em] font-semibold transition-all shadow-md focus:outline-none"
        >
          <Maximize2 className="w-3.5 h-3.5" />
          <span>FULL-SCREEN SITE</span>
        </button>
      </div>

      {/* 3D Perspective Stage Container */}
      <div
        className="w-full flex-1 flex items-center justify-center p-4 sm:p-8 perspective-container relative overflow-hidden"
        style={{ perspective: "2000px" }}
      >
        {/* Ambient Studio Lighting Glows */}
        <div className="absolute w-[800px] h-[500px] bg-[#c59d5f]/10 rounded-full blur-[140px] pointer-events-none -z-10" />
        <div className="absolute -bottom-20 w-[1000px] h-[300px] bg-[#22160f]/60 rounded-full blur-[100px] pointer-events-none -z-10" />

        {/* 3D Laptop / Display Body */}
        <div
          className="relative transition-transform duration-700 ease-out origin-center"
          style={{
            transform: transformStyle,
            transformStyle: "preserve-3d",
          }}
        >
          {/* Laptop Screen Display Lid */}
          <div
            className="w-[92vw] max-w-[1240px] h-[78vh] max-h-[820px] bg-[#1a1410] rounded-[24px] p-4 sm:p-5 shadow-[0_50px_100px_-20px_rgba(0,0,0,0.9),0_30px_60px_-30px_rgba(197,157,95,0.15)] border-[3px] border-[#382b22] relative flex flex-col"
            style={{ transformStyle: "preserve-3d" }}
          >
            {/* Top Bezel with Camera Notch */}
            <div className="w-full flex items-center justify-between px-4 pb-3 pt-1">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#ff5f56]" />
                <span className="w-2.5 h-2.5 rounded-full bg-[#ffbd2e]" />
                <span className="w-2.5 h-2.5 rounded-full bg-[#27c93f]" />
              </div>

              {/* Minimal camera lens & indicator */}
              <div className="flex items-center gap-2 px-3 py-0.5 bg-[#0a0807] rounded-full border border-[#2e231b]">
                <span className="w-2 h-2 rounded-full bg-[#050403] border border-[#443328]" />
                <span className="text-[9px] font-mono text-[#8a7563] tracking-widest">
                  AURELIA 4K PRO
                </span>
              </div>

              <div className="w-16 text-right flex items-center justify-end gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-[9px] font-mono text-[#c59d5f]">60 FPS</span>
              </div>
            </div>

            {/* Inner Live Web Page Iframe / Scrolling Container */}
            <div className="w-full flex-1 bg-[#0f0c0a] rounded-[14px] overflow-y-auto overflow-x-hidden relative border border-[#2a1e16] shadow-inner select-auto">
              {children}
            </div>

            {/* Glossy Screen Reflection Glare */}
            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/[0.03] to-transparent rounded-[24px] pointer-events-none" />
          </div>

          {/* 3D Laptop Keyboard Base Deck (Extends into 3D Depth) */}
          <div
            className="w-[96vw] max-w-[1300px] h-12 bg-gradient-to-b from-[#2a201a] via-[#1c1511] to-[#0c0907] rounded-b-[20px] mx-auto -mt-2 border-t border-[#4a3a2e] shadow-[0_40px_80px_rgba(0,0,0,0.95)] flex items-center justify-center relative"
            style={{
              transform: "rotateX(75deg) translateZ(-20px)",
              transformOrigin: "top center",
            }}
          >
            {/* Center notch thumb indent */}
            <div className="w-28 h-2 bg-[#120d0a] rounded-b-md border-b border-[#3d2f25]" />
          </div>
        </div>
      </div>

      {/* Bottom Hint Indicator */}
      <div className="w-full py-3 bg-[#0a0807] border-t border-[#1c140f] text-center text-[11px] font-mono text-[#8a7563] flex items-center justify-center gap-6">
        <span>Scroll inside the laptop viewport to explore the entire site</span>
        <span className="hidden sm:inline">•</span>
        <span className="hidden sm:inline">Use Presets above to shift camera perspectives</span>
      </div>
    </div>
  );
};
