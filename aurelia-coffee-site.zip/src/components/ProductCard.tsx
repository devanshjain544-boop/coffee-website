import React from "react";
import { Product } from "../config/brandConfig";
import { Eye, Plus } from "lucide-react";

interface ProductCardProps {
  product: Product;
  onViewProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onViewProduct,
  onAddToCart,
}) => {
  return (
    <div
      className="group relative bg-[#15100d] border border-[#2c2018] hover:border-[#c59d5f]/80 transition-all duration-500 flex flex-col justify-between overflow-hidden"
      id={`product-card-${product.id}`}
    >
      {/* Category Badge & Roast level */}
      <div className="p-6 pb-0 flex justify-between items-center z-10">
        <span className="text-[10px] font-mono uppercase tracking-[0.25em] text-[#c59d5f]">
          {product.category}
        </span>
        <span className="text-[10px] uppercase tracking-wider text-[#8a7563]">
          {product.roastLevel}
        </span>
      </div>

      {/* Product Image Container with hover reveal */}
      <div className="relative aspect-square w-full p-8 flex items-center justify-center overflow-hidden bg-[#0d0a08]">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-contain filter contrast-110 group-hover:scale-108 transition-transform duration-700 ease-out"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#15100d] via-transparent to-transparent opacity-50" />

        {/* Quick View Floating Overlay on Hover */}
        <div className="absolute inset-0 flex items-center justify-center gap-3 bg-[#0f0c0a]/60 backdrop-blur-xs opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <button
            onClick={() => onViewProduct(product)}
            className="px-4 py-2 bg-[#f4eee6] text-[#0f0c0a] text-[11px] uppercase tracking-[0.2em] font-semibold flex items-center gap-2 hover:bg-[#c59d5f] transition-colors focus:outline-none"
            id={`btn-view-${product.id}`}
          >
            <Eye className="w-3.5 h-3.5" />
            VIEW PRODUCT
          </button>
        </div>
      </div>

      {/* Product Details Area */}
      <div className="p-6 pt-2 flex flex-col flex-grow justify-between border-t border-[#221812]">
        <div>
          <h3 className="font-serif-luxury text-2xl font-light text-[#f4eee6] group-hover:text-[#c59d5f] transition-colors duration-300 mb-2">
            {product.name}
          </h3>

          <p className="text-xs text-[#a8947f] font-light leading-relaxed line-clamp-2 mb-4">
            {product.description}
          </p>

          {/* Tasting notes chips */}
          <div className="flex flex-wrap gap-1.5 mb-6">
            {product.notes.map((note, idx) => (
              <span
                key={idx}
                className="text-[9px] uppercase tracking-wider px-2 py-0.5 bg-[#1f1712] text-[#d6c7b2] border border-[#33241b]"
              >
                {note}
              </span>
            ))}
          </div>
        </div>

        {/* Price & Action Row */}
        <div className="pt-4 border-t border-[#221812] flex items-center justify-between">
          <div>
            <span className="text-[10px] text-[#8a7563] uppercase tracking-wider block">
              {product.weight}
            </span>
            <span className="font-mono text-lg text-[#f4eee6] font-medium" id={`price-${product.id}`}>
              {product.price}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onViewProduct(product)}
              className="px-3 py-2 text-[10px] uppercase tracking-[0.2em] border border-[#443328] hover:border-[#c59d5f] text-[#d6c7b2] hover:text-[#f4eee6] transition-colors focus:outline-none"
              id={`view-action-${product.id}`}
            >
              DETAILS
            </button>
            <button
              onClick={() => onAddToCart(product)}
              className="p-2 bg-[#c59d5f] hover:bg-[#dfbc84] text-[#0f0c0a] transition-colors focus:outline-none"
              title="Add to ritual cart"
              id={`add-action-${product.id}`}
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
