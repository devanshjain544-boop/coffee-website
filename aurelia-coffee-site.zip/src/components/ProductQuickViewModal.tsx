import React, { useState } from "react";
import { Product } from "../config/brandConfig";
import { X, Sparkles, Check, ShoppingBag } from "lucide-react";

interface ProductQuickViewModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, grind: string) => void;
}

export const ProductQuickViewModal: React.FC<ProductQuickViewModalProps> = ({
  product,
  onClose,
  onAddToCart,
}) => {
  const [selectedGrind, setSelectedGrind] = useState("Whole Bean");
  const [addedSuccess, setAddedSuccess] = useState(false);

  if (!product) return null;

  const grindOptions = ["Whole Bean", "Coarse (French Press)", "Medium (Pour Over / Drip)", "Fine (Espresso)"];

  const handleAdd = () => {
    onAddToCart(product, selectedGrind);
    setAddedSuccess(true);
    setTimeout(() => {
      setAddedSuccess(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-8 bg-[#0a0807]/90 backdrop-blur-md animate-in fade-in duration-300">
      <div
        className="relative w-full max-w-3xl bg-[#140f0c] border border-[#33241b] shadow-2xl p-6 md:p-10 overflow-hidden flex flex-col md:flex-row gap-8"
        id="product-modal-container"
      >
        {/* Close button */}
        <button
          onClick={onClose}
          aria-label="Close modal"
          className="absolute top-4 right-4 p-2 text-[#a8947f] hover:text-[#f4eee6] hover:bg-[#221812] transition-colors z-20 focus:outline-none"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Left: Product Image */}
        <div className="w-full md:w-1/2 aspect-square bg-[#0c0907] border border-[#261b14] flex items-center justify-center p-6 relative">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-contain filter contrast-110"
            referrerPolicy="no-referrer"
          />
          <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2.5 py-1 bg-[#0f0c0a]/80 border border-[#33241b] text-[9px] font-mono uppercase tracking-wider text-[#c59d5f]">
            <Sparkles className="w-3 h-3 text-[#c59d5f]" />
            <span>SPECIALTY LOT</span>
          </div>
        </div>

        {/* Right: Product Details */}
        <div className="w-full md:w-1/2 flex flex-col justify-between">
          <div>
            <span className="text-[10px] font-mono uppercase tracking-[0.25em] text-[#c59d5f] block mb-1">
              {product.category} • {product.roastLevel}
            </span>

            <h3 className="font-serif-luxury text-3xl font-light text-[#f4eee6] mb-2">
              {product.name}
            </h3>

            <div className="font-mono text-2xl text-[#c59d5f] font-medium mb-4">
              {product.price}
              <span className="text-xs text-[#8a7563] ml-2 font-sans font-normal">
                ({product.weight})
              </span>
            </div>

            <p className="text-xs text-[#a8947f] font-light leading-relaxed mb-6">
              {product.description}
            </p>

            {/* Flavor notes */}
            <div className="mb-6">
              <span className="text-[10px] uppercase tracking-wider text-[#d6c7b2] block mb-2 font-medium">
                Tasting Notes
              </span>
              <div className="flex flex-wrap gap-2">
                {product.notes.map((note, i) => (
                  <span
                    key={i}
                    className="text-[10px] uppercase tracking-wider px-2.5 py-1 bg-[#1f1712] text-[#f4eee6] border border-[#33241b]"
                  >
                    {note}
                  </span>
                ))}
              </div>
            </div>

            {/* Grind selector */}
            <div className="mb-6">
              <span className="text-[10px] uppercase tracking-wider text-[#d6c7b2] block mb-2 font-medium">
                Grind Specification
              </span>
              <div className="grid grid-cols-2 gap-2">
                {grindOptions.map((grind) => (
                  <button
                    key={grind}
                    onClick={() => setSelectedGrind(grind)}
                    className={`text-[10px] uppercase tracking-wider py-2 px-2 text-left border transition-all ${
                      selectedGrind === grind
                        ? "border-[#c59d5f] bg-[#221812] text-[#f4eee6]"
                        : "border-[#2c2018] text-[#8a7563] hover:text-[#d6c7b2]"
                    }`}
                  >
                    {grind}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Action button */}
          <button
            onClick={handleAdd}
            disabled={addedSuccess}
            className={`w-full py-4 text-xs uppercase tracking-[0.2em] font-semibold flex items-center justify-center gap-2 transition-all ${
              addedSuccess
                ? "bg-emerald-600 text-white"
                : "bg-[#c59d5f] hover:bg-[#dfbc84] text-[#0f0c0a]"
            }`}
          >
            {addedSuccess ? (
              <>
                <Check className="w-4 h-4" />
                ADDED TO RITUAL
              </>
            ) : (
              <>
                <ShoppingBag className="w-4 h-4" />
                ADD TO CART • {product.price}
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
