import React, { useState, useEffect, useRef } from "react";
import { tapticEngine } from "../utils/tapticEngine";

interface ScrollProgressBarProps {
  containerId?: string;
}

export const ScrollProgressBar: React.FC<ScrollProgressBarProps> = ({ containerId }) => {
  const [scrollProgress, setScrollProgress] = useState(0);
  const [activeSectionName, setActiveSectionName] = useState("HOME");
  const lastSectionRef = useRef<string>("HOME");

  useEffect(() => {
    const handleScroll = () => {
      let currentProgress = 0;
      let currentY = 0;

      if (containerId) {
        const container = document.getElementById(containerId);
        if (container) {
          const total = container.scrollHeight - container.clientHeight;
          currentY = container.scrollTop;
          currentProgress = total > 0 ? (currentY / total) * 100 : 0;
        }
      } else {
        const winScroll = document.documentElement.scrollTop || document.body.scrollTop;
        const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        currentY = winScroll;
        currentProgress = height > 0 ? (winScroll / height) * 100 : 0;
      }

      setScrollProgress(Math.min(100, Math.max(0, currentProgress)));

      // Section detection for navigation context
      const sections = [
        { id: "hero-section", name: "00 / HOME" },
        { id: "our-coffee", name: "01 / OUR COFFEE" },
        { id: "the-beans", name: "02 / THE BEANS" },
        { id: "process-section", name: "03 / PROCESS" },
        { id: "signature-section", name: "04 / SIGNATURE" },
        { id: "collection-section", name: "05 / COLLECTION" },
        { id: "story-section", name: "06 / OUR STORY" },
        { id: "experience-section", name: "07 / THE RITUAL" },
        { id: "final-cta-section", name: "08 / DISCOVER" },
      ];

      for (let i = sections.length - 1; i >= 0; i--) {
        const el = document.getElementById(sections[i].id);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= window.innerHeight * 0.45) {
            const detectedName = sections[i].name;
            if (lastSectionRef.current !== detectedName) {
              lastSectionRef.current = detectedName;
              setActiveSectionName(detectedName);
              tapticEngine.trigger("section");
            }
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll(); // Initial calculation

    return () => window.removeEventListener("scroll", handleScroll);
  }, [containerId]);

  return (
    <div
      className="fixed top-0 left-0 right-0 z-[100] pointer-events-none"
      id="scroll-progress-container"
      aria-hidden="true"
    >
      {/* Background track (subtle translucent espresso brown) */}
      <div className="w-full h-[3px] bg-[#1a1410]/50 backdrop-blur-xs relative overflow-hidden">
        {/* Slim, gold-colored progress bar filling as user scrolls down */}
        <div
          className="h-full bg-gradient-to-r from-[#c59d5f] via-[#dfbc84] to-[#f4eee6] transition-all duration-150 ease-out origin-left shadow-[0_0_10px_rgba(197,157,95,0.7)]"
          style={{
            width: `${scrollProgress}%`,
          }}
          id="scroll-progress-bar"
        />
      </div>

      {/* Subtle floating gold context pill on top-right (active section indicator) */}
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex justify-end">
        <div
          className={`mt-2.5 px-2.5 py-0.5 rounded-full bg-[#0f0c0a]/85 backdrop-blur-md border border-[#c59d5f]/30 text-[9px] font-mono tracking-[0.2em] text-[#d6c7b2] flex items-center gap-2 transition-opacity duration-300 ${
            scrollProgress > 3 ? "opacity-100" : "opacity-0"
          }`}
          id="scroll-context-badge"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-[#c59d5f] animate-pulse" />
          <span className="text-[#c59d5f] font-semibold">{activeSectionName}</span>
          <span className="text-[#8a7563]">{Math.round(scrollProgress)}%</span>
        </div>
      </div>
    </div>
  );
};
