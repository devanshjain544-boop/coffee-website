/**
 * =====================================================================
 * AURELIA COFFEE — BRAND CONFIGURATION & CONTENT MANAGEMENT
 * =====================================================================
 *
 * You can customize all 9 essential brand & website elements right here:
 * 1. Brand Name (brand.name)
 * 2. Tagline (brand.tagline)
 * 3. Colors (colors)
 * 4. Images (images)
 * 5. Product Names (products[].name)
 * 6. Product Prices (products[].price)
 * 7. Website Text (content)
 * 8. Scroll Animation Speed (animation)
 * 9. 3D Model Files & Scene Settings (threeD)
 */

export interface Product {
  id: string;
  name: string;
  category: string;
  roastLevel: string;
  notes: string[];
  description: string;
  price: string; // Clearly editable placeholder price
  weight: string;
  image: string;
  featured?: boolean;
  accentColor?: string;
}

export const brandConfig = {
  // 1. BRAND NAME & IDENTITY
  brand: {
    name: "AURELIA COFFEE",
    shortName: "Aurelia",
    established: "2024",
    // 2. TAGLINE
    tagline: "Crafted for the moments that matter.",
    subtagline: "From carefully selected beans to your daily ritual.",
    origin: "Artisanal Specialty Roasters",
    contactEmail: "concierge@aureliacoffee.com",
    address: "742 Evergreen Atelier, Milan & Zurich",
  },

  // 3. COLOR PALETTE (Dark espresso, Warm cream, Coffee beige, Soft tan, Black, Muted gold)
  colors: {
    espressoDark: "#0f0c0a",      // Deep obsidian espresso canvas
    espressoSurface: "#1a1512",   // Card surface espresso
    espressoCardHover: "#241d18", // Hover card background
    warmCream: "#f4eee6",         // High contrast luxury text cream
    coffeeBeige: "#d6c7b2",       // Secondary subheadings beige
    softTan: "#a8947f",           // Muted body text / borders
    pureBlack: "#050403",         // Deepest shadows
    mutedGold: "#c59d5f",         // Refined warm metallic gold
    mutedGoldLight: "#dfbc84",    // Highlight gold
    mutedGoldDark: "#91703c",     // Deep etched gold
  },

  // 4. IMAGES (Curated high-resolution editorial coffee photography)
  // Replace any of these URLs with your own custom images or 3D asset renders!
  images: {
    heroCoffee: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?q=80&w=1920&auto=format&fit=crop",
    beansMacro: "https://images.unsplash.com/photo-1559056199-641a0ac8b55e?q=80&w=1600&auto=format&fit=crop",
    roastingProcess: "https://images.unsplash.com/photo-1518832553480-cd0e625ed3e6?q=80&w=1200&auto=format&fit=crop",
    signatureCup: "https://images.unsplash.com/photo-1517256064527-09c73fc73e38?q=80&w=1600&auto=format&fit=crop",
    storyLandscape: "https://images.unsplash.com/photo-1447933601403-0c6688de566e?q=80&w=1600&auto=format&fit=crop",
    experienceMorning: "https://images.unsplash.com/photo-1442512595331-e89e73853f31?q=80&w=1600&auto=format&fit=crop",
    craftPackaging: "https://images.unsplash.com/photo-1587734195503-904fca47e0e9?q=80&w=1200&auto=format&fit=crop",
  },

  // 5 & 6. PRODUCT NAMES, DESCRIPTIONS & EDITABLE PLACEHOLDER PRICES
  products: [
    {
      id: "aurelia-classic",
      name: "Aurelia Classic",
      category: "CLASSIC ROAST",
      roastLevel: "Medium Roast",
      notes: ["Cacao Nib", "Valencia Orange", "Wild Honey"],
      description: "Our signature medium roast celebrates sweet balance, gentle acidity, and silky body sourced from single-estate elevations.",
      price: "₹749", // Indian Rupee rate
      weight: "250g / 8.8oz Whole Bean",
      image: "https://images.unsplash.com/photo-1587734195503-904fca47e0e9?q=80&w=1000&auto=format&fit=crop",
      featured: true,
      accentColor: "#c59d5f",
    },
    {
      id: "aurelia-dark-roast",
      name: "Aurelia Dark Roast",
      category: "DARK ROAST",
      roastLevel: "French Dark Roast",
      notes: ["Smoked Molasses", "Black Truffle", "85% Dark Chocolate"],
      description: "Deep, intense, and profoundly velvety. Roasted slowly over cast-iron drums to coax out smoky undertones and lingering sweetness.",
      price: "₹799", // Indian Rupee rate
      weight: "250g / 8.8oz Whole Bean",
      image: "https://images.unsplash.com/photo-1610632380989-680fe40816c6?q=80&w=1000&auto=format&fit=crop",
      featured: false,
      accentColor: "#8f6735",
    },
    {
      id: "aurelia-signature",
      name: "Aurelia Signature",
      category: "SIGNATURE BLEND",
      roastLevel: "Omni Roast",
      notes: ["Bergamot Blossom", "Madagascar Vanilla", "Brown Butter"],
      description: "The crown jewel of our roastery. A proprietary microlot blend harmonizing Ethiopian floral aromatics with Colombian caramel structure.",
      price: "₹899", // Indian Rupee rate
      weight: "250g / 8.8oz Whole Bean",
      image: "https://images.unsplash.com/photo-1559525839-b184a4d698c7?q=80&w=1000&auto=format&fit=crop",
      featured: true,
      accentColor: "#dfbc84",
    },
  ] as Product[],

  // 7. WEBSITE TEXT & HEADINGS ACROSS ALL SECTIONS
  content: {
    hero: {
      eyebrow: "RESERVE COLLECTION",
      title: "THE ART OF A PERFECT CUP",
      subtext: "From carefully selected beans to your daily ritual.",
      primaryCta: "EXPLORE COFFEE",
      secondaryCta: "OUR PHILOSOPHY",
    },
    section01: {
      number: "01",
      heading: "COFFEE, CAREFULLY CHOSEN.",
      description:
        "At Aurelia, exceptional coffee is not an accident—it is an uncompromising devotion to soil health, hand-picked cherries, and micro-climate stewardship. We travel to secluded volcanic estates to source only the top 1% of harvested Arabica beans.",
      categories: [
        {
          title: "CLASSIC ROAST",
          origin: "Huila, Colombia (1,850m)",
          description: "Harmonious sweetness, gentle stone-fruit acidity, and a creamy hazelnut finish.",
          image: "https://images.unsplash.com/photo-1497636577773-f1231844b336?q=80&w=800&auto=format&fit=crop",
        },
        {
          title: "DARK ROAST",
          origin: "Antigua, Guatemala (1,600m)",
          description: "Full-bodied richness with dark roasted cocoa, toasted almond, and molasses.",
          image: "https://images.unsplash.com/photo-1511920170033-f8396924c348?q=80&w=800&auto=format&fit=crop",
        },
        {
          title: "SIGNATURE BLEND",
          origin: "Yirgacheffe & Tarrazú Blend",
          description: "Complex jasmine floral fragrance lifted by crisp blood orange and silky caramel.",
          image: "https://images.unsplash.com/photo-1509785307050-d4066910ec1e?q=80&w=800&auto=format&fit=crop",
        },
      ],
    },
    section02: {
      number: "02",
      heading: "IT STARTS WITH THE BEAN.",
      quote: "Every cup begins long before the first sip.",
      subtext:
        "Grown under shaded canopy in nutrient-dense mineral soils, each cherry is hand-harvested at peak Brix sweetness. Only unblemished whole cherries pass through our optical sorters before undergoing 36-hour controlled anaerobic fermentation.",
      stats: [
        { label: "Elevation", value: "1,950m", detail: "High altitude volcanic soil" },
        { label: "Sourcing", value: "Direct Trade", detail: "100% fair artisan partnerships" },
        { label: "Sorting", value: "Triple Hand-Selected", detail: "Zero defect tolerance" },
      ],
    },
    section03: {
      number: "03",
      heading: "FROM BEAN TO CUP",
      subheading: "THE FOUR PILLARS OF OUR CRAFT",
      stages: [
        {
          step: "01",
          title: "SELECT",
          description: "High-altitude shade-grown cherries harvested exclusively at optimum sugar density.",
          image: "https://images.unsplash.com/photo-1524350876685-274059332603?q=80&w=800&auto=format&fit=crop",
        },
        {
          step: "02",
          title: "ROAST",
          description: "Small-batch cast iron drum roasting calibrated precisely by bean moisture and density.",
          image: "https://images.unsplash.com/photo-1518832553480-cd0e625ed3e6?q=80&w=800&auto=format&fit=crop",
        },
        {
          step: "03",
          title: "GRIND",
          description: "Titanium burr geometry engineered for unimodal particle size and uniform extraction.",
          image: "https://images.unsplash.com/photo-1589396575653-c09c794ff6a6?q=80&w=800&auto=format&fit=crop",
        },
        {
          step: "04",
          title: "BREW",
          description: "Optimal water purity at 93.5°C releasing nuanced aromatic bouquets and delicate crema.",
          image: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?q=80&w=800&auto=format&fit=crop",
        },
      ],
    },
    section04: {
      number: "04",
      heading: "YOUR SIGNATURE CUP.",
      description: "Rich aroma. Balanced flavor. A coffee experience worth slowing down for.",
      cta: "DISCOVER THE BLEND",
      details: [
        { title: "Aroma", desc: "Smoked cedar, jasmine blossom, candied orange peel" },
        { title: "Body", desc: "Silky, velvety weight with lingering bittersweet cocoa" },
        { title: "Finish", desc: "Clean, lingering honey sweetness without astringency" },
      ],
    },
    section05: {
      number: "05",
      heading: "THE COFFEE COLLECTION",
      subheading: "SMALL-BATCH ROASTS SHIPPED WITHIN 48 HOURS OF DE-GASSING",
    },
    section06: {
      number: "06",
      heading: "MORE THAN COFFEE.",
      story: [
        "Aurelia was born in a quiet atelier with a singular, quiet obsession: to restore reverence to the morning cup. In an era that celebrates rushing, we believe the time spent brewing is an essential pause in the rhythm of the day.",
        "We foster intimate generational partnerships with single-family estates across Colombia, Ethiopia, and Guatemala. By paying premiums well above fair-trade minimums, we empower agricultural innovation while preserving delicate mountain biomes.",
        "When you open a bag of Aurelia, you are tasting months of sun, soil, patient fermentation, and precise thermodynamic roasting—crafted expressly for your table.",
      ],
      signatureTitle: "Head of Roasting & Sourcing",
      signatureName: "Valeria Sterling",
    },
    section07: {
      number: "07",
      words: ["SLOW DOWN.", "POUR.", "ENJOY."],
      subtext: "A daily ritual distilled to its purest, most sensory form.",
    },
    section08: {
      number: "08",
      heading: "YOUR NEXT CUP AWAITS.",
      subtext: "Discover coffee made for your everyday moments.",
      cta: "SHOP COFFEE",
      perks: [
        "Complimentary boutique shipping over ₹999",
        "Roasted fresh to order every Tuesday & Friday",
        "Hermetically sealed foil valve pouch with UV barrier",
      ],
    },
    footer: {
      copyright: "© 2024–2026 Aurelia Coffee Co. All rights reserved.",
      disclaimer: "Fictional client demonstration crafted with agency-quality 3D and scroll storytelling.",
    },
  },

  // 8. SCROLL ANIMATION & GSAP SPEED SETTINGS
  animation: {
    scrubSpeed: 1, // GSAP ScrollTrigger scrub responsiveness (1 = smooth, 2 = slower luxury drag)
    fadeDuration: 0.8,
    cameraParallaxMultiplier: 0.05,
    cameraFov: 45,
    autoRotateSpeed: 0.004,
  },

  // 9. 3D MODEL FILES & PROCEDURAL 3D SETTINGS
  threeD: {
    // You can replace these with custom .glb / .gltf files if you have external 3D models!
    // Our built-in procedural 3D components render high-fidelity ceramic coffee cup,
    // roasted coffee beans, and sleek packaging automatically with zero loading lag.
    modelPaths: {
      coffeeCupGlb: "/models/coffee_cup.glb",       // Optional external model path
      coffeeBeansGlb: "/models/coffee_beans.glb",   // Optional external model path
      coffeePackageGlb: "/models/coffee_bag.glb",   // Optional external model path
    },
    cupColor: "#1a1614",      // Matte porcelain glaze color
    cupAccentColor: "#c59d5f",// Gold rim trim
    saucerColor: "#151210",
    coffeeLiquidColor: "#1f120a",
    cremaColor: "#a67b43",
    particleCount: 24,        // Floating steam particles
    beanCount: 16,            // Floating roasted beans in scene
    enableMouseParallax: true,
  },
};
