import React, { useRef } from "react";
import { brandConfig } from "../config/brandConfig";

export const BeanSection: React.FC = () => {
  const { section02 } = brandConfig.content;
  const sectionRef = useRef<HTMLElement>(null);

  return (
    <section
      ref={sectionRef}
      id="the-beans"
      className="relative min-h-screen py-32 overflow-hidden bg-gradient-to-b from-[#0f0c0a] via-[#140f0c] to-[#0f0c0a] border-t border-[#2a1e16]/60 flex items-center"
    >
      {/* Background macro bean visual layer with subtle scaling & parallax feel */}
      <div className="absolute inset-0 z-0 opacity-25 mix-blend-screen pointer-events-none">
        <img
          src={brandConfig.images.beansMacro}
          alt="Freshly roasted whole coffee beans macro"
          className="w-full h-full object-cover object-center filter contrast-125 brightness-75 scale-105"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0f0c0a] via-[#0f0c0a]/70 to-[#0f0c0a]" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0f0c0a] via-transparent to-[#0f0c0a]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-12 w-full">
        {/* Section Tag */}
        <div className="flex items-center gap-3 mb-6">
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#c59d5f]">
            SECTION {section02.number}
          </span>
          <span className="w-12 h-[1px] bg-[#c59d5f]/40"></span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Heading & Philosophical Quote */}
          <div className="lg:col-span-7">
            <h2
              className="font-serif-luxury text-4xl sm:text-6xl md:text-7xl font-light tracking-tight text-[#f4eee6] leading-[1.1] mb-8"
              id="bean-section-heading"
            >
              {section02.heading}
            </h2>

            {/* Prominent Quote: "Every cup begins long before the first sip." */}
            <div className="relative pl-6 border-l-2 border-[#c59d5f] mb-8">
              <blockquote className="font-serif-luxury text-2xl sm:text-3xl md:text-4xl italic text-[#d6c7b2] font-light leading-snug">
                "{section02.quote}"
              </blockquote>
            </div>

            <p className="font-sans text-sm md:text-base text-[#a8947f] font-light leading-relaxed max-w-2xl mb-12">
              {section02.subtext}
            </p>

            {/* Sourcing & Quality Metrics */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-6 border-t border-[#2a1e16]">
              {section02.stats.map((stat, i) => (
                <div key={i} className="flex flex-col">
                  <span className="font-serif-luxury text-2xl md:text-3xl text-[#c59d5f] font-light mb-1">
                    {stat.value}
                  </span>
                  <span className="text-xs uppercase tracking-[0.2em] text-[#f4eee6] font-medium mb-1">
                    {stat.label}
                  </span>
                  <span className="text-[11px] text-[#8a7563] font-light">
                    {stat.detail}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Right Column: Featured Focus Card with High-Res Bean Macro */}
          <div className="lg:col-span-5">
            <div className="relative p-2 bg-gradient-to-b from-[#33241b] to-[#1a130e] rounded-sm shadow-2xl border border-[#443328]/50 group">
              <div className="relative aspect-[4/5] overflow-hidden rounded-sm bg-[#080605]">
                <img
                  src={brandConfig.images.beansMacro}
                  alt="Aurelia Selected Single Estate Arabica Beans"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000 ease-out"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0f0c0a] via-transparent to-transparent opacity-80" />

                {/* Floating Micro-data Overlay */}
                <div className="absolute bottom-6 left-6 right-6 p-4 bg-[#0f0c0a]/85 backdrop-blur-md border border-[#33241b] text-xs">
                  <div className="flex justify-between items-center text-[#c59d5f] font-mono uppercase tracking-[0.2em] text-[10px] mb-1">
                    <span>SPECIES: 100% ARABICA</span>
                    <span>DEFECTS: 0%</span>
                  </div>
                  <p className="text-[#d6c7b2] font-serif text-sm">
                    Geisha & Typica Heirloom Varietals
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
