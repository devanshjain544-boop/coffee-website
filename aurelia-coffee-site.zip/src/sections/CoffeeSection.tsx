import React from "react";
import { brandConfig } from "../config/brandConfig";
import { ArrowUpRight } from "lucide-react";

interface CoffeeSectionProps {
  onSelectCategory?: (category: string) => void;
}

export const CoffeeSection: React.FC<CoffeeSectionProps> = ({ onSelectCategory }) => {
  const { section01 } = brandConfig.content;

  return (
    <section
      id="our-coffee"
      className="relative py-28 px-6 md:px-12 max-w-7xl mx-auto border-t border-[#2a1e16]/60"
    >
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-8">
        <div className="max-w-2xl">
          <div className="flex items-center gap-3 mb-4">
            <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#c59d5f]">
              SECTION {section01.number}
            </span>
            <span className="w-12 h-[1px] bg-[#c59d5f]/40"></span>
          </div>
          <h2
            className="font-serif-luxury text-3xl sm:text-5xl md:text-6xl font-light tracking-tight text-[#f4eee6] leading-[1.15]"
            id="coffee-section-heading"
          >
            {section01.heading}
          </h2>
        </div>

        <p className="max-w-md font-sans text-sm md:text-base text-[#a8947f] font-light leading-relaxed">
          {section01.description}
        </p>
      </div>

      {/* Three Coffee Categories Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8" id="coffee-categories-grid">
        {section01.categories.map((cat, index) => (
          <div
            key={index}
            onClick={() => onSelectCategory && onSelectCategory(cat.title)}
            className="group relative cursor-pointer bg-[#16120f] border border-[#2a1e16] hover:border-[#c59d5f]/70 transition-all duration-500 overflow-hidden flex flex-col justify-between"
            id={`coffee-card-${index}`}
          >
            {/* Image Container with subtle zoom on hover */}
            <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#0a0807]">
              <img
                src={cat.image}
                alt={cat.title}
                className="w-full h-full object-cover grayscale-[30%] group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700 ease-out"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#16120f] via-transparent to-transparent opacity-80" />
              
              {/* Corner Badge */}
              <div className="absolute top-4 right-4 bg-[#0f0c0a]/80 backdrop-blur-md p-2 rounded-full border border-[#33241b] text-[#d6c7b2] group-hover:text-[#0f0c0a] group-hover:bg-[#c59d5f] transition-all duration-300">
                <ArrowUpRight className="w-4 h-4" />
              </div>
            </div>

            {/* Content Area */}
            <div className="p-8 flex flex-col flex-grow justify-between">
              <div>
                <p className="text-[10px] uppercase font-mono tracking-[0.25em] text-[#c59d5f] mb-2">
                  {cat.origin}
                </p>
                <h3 className="font-serif-luxury text-2xl font-light text-[#f4eee6] group-hover:text-[#c59d5f] transition-colors duration-300 mb-3">
                  {cat.title}
                </h3>
                <p className="text-xs md:text-sm text-[#a8947f] font-light leading-relaxed">
                  {cat.description}
                </p>
              </div>

              {/* Bottom line indicator */}
              <div className="mt-8 pt-4 border-t border-[#2a1e16] flex items-center justify-between text-[11px] uppercase tracking-[0.2em] text-[#d6c7b2] group-hover:text-[#f4eee6] transition-colors">
                <span>View Profile</span>
                <span className="w-6 h-[1px] bg-[#a8947f] group-hover:w-10 group-hover:bg-[#c59d5f] transition-all duration-300"></span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
