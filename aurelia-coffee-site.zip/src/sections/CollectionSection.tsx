import React from "react";
import { brandConfig, Product } from "../config/brandConfig";
import { ProductCard } from "../components/ProductCard";

interface CollectionSectionProps {
  onViewProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

export const CollectionSection: React.FC<CollectionSectionProps> = ({
  onViewProduct,
  onAddToCart,
}) => {
  const { section05 } = brandConfig.content;

  return (
    <section
      id="collection-section"
      className="relative py-32 px-6 md:px-12 max-w-7xl mx-auto border-t border-[#2a1e16]/60"
    >
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#c59d5f]">
              SECTION {section05.number}
            </span>
            <span className="w-12 h-[1px] bg-[#c59d5f]/40"></span>
          </div>
          <h2
            className="font-serif-luxury text-4xl sm:text-6xl md:text-7xl font-light tracking-tight text-[#f4eee6] leading-[1.1]"
            id="collection-section-heading"
          >
            {section05.heading}
          </h2>
        </div>

        <p className="font-mono text-xs uppercase tracking-[0.25em] text-[#c59d5f]">
          {section05.subheading}
        </p>
      </div>

      {/* Product Cards Grid: Aurelia Classic, Aurelia Dark Roast, Aurelia Signature */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8" id="products-collection-grid">
        {brandConfig.products.map((product) => (
          <ProductCard
            key={product.id}
            product={product}
            onViewProduct={onViewProduct}
            onAddToCart={onAddToCart}
          />
        ))}
      </div>

      {/* Roaster Quality Guarantee */}
      <div className="mt-16 p-8 border border-[#2a1e16] bg-[#140f0c] flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-full border border-[#c59d5f] flex items-center justify-center font-serif text-[#c59d5f] text-lg font-light">
            A
          </div>
          <div>
            <h4 className="font-serif-luxury text-lg text-[#f4eee6]">
              Aurelia Peak Freshness Promise
            </h4>
            <p className="text-xs text-[#a8947f] font-light">
              Every bag stamped with roast date, roast batch ID, and degassing valve status.
            </p>
          </div>
        </div>

        <span className="text-xs font-mono uppercase tracking-[0.2em] text-[#c59d5f]">
          ROASTED FRESH EVERY 72 HOURS
        </span>
      </div>
    </section>
  );
};
