import React, { useState, useEffect, useRef } from "react";
import { brandConfig } from "../config/brandConfig";
import { audioService } from "../utils/audioService";
import { tapticEngine } from "../utils/tapticEngine";
import { Sparkles } from "lucide-react";

export const ExperienceSection: React.FC = () => {
  const { section07 } = brandConfig.content;
  const [activeWordIndex, setActiveWordIndex] = useState(0);
  const sectionRef = useRef<HTMLElement>(null);

  const images = [
    brandConfig.images.experienceMorning,
    brandConfig.images.signatureCup,
    brandConfig.images.heroCoffee,
  ];

  const imageCaptions = [
    "01 / The morning stillness — measuring whole beans by the gram",
    "02 / The blooming pour — water meeting freshly ground coffee at 93°C",
    "03 / The quiet sip — notes of cacao, wild honey, and citrus blossom",
  ];

  // Trigger ambient sound when reaching the 'Experience' section
  useEffect(() => {
    const handleScroll = () => {
      if (!sectionRef.current) return;
      const rect = sectionRef.current.getBoundingClientRect();
      const windowHeight = window.innerHeight;

      // When section enters the viewport (between 20% and 85% of viewport)
      const isInExperience = rect.top <= windowHeight * 0.8 && rect.bottom >= windowHeight * 0.2;

      if (isInExperience) {
        audioService.triggerExperienceEnter();
      } else {
        audioService.triggerExperienceLeave();
      }

      // Progressively update active word & image based on travel through this section
      if (rect.top <= windowHeight && rect.bottom >= 0) {
        const totalTravel = windowHeight + rect.height;
        const progress = Math.min(Math.max((windowHeight - rect.top) / totalTravel, 0), 1);

        if (progress < 0.4) {
          setActiveWordIndex(0);
        } else if (progress < 0.7) {
          setActiveWordIndex(1);
        } else {
          setActiveWordIndex(2);
        }
      }
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll(); // Initial check on load

    return () => {
      window.removeEventListener("scroll", handleScroll);
      audioService.triggerExperienceLeave();
    };
  }, []);

  const handleWordClick = (index: number) => {
    setActiveWordIndex(index);
    audioService.triggerExperienceEnter();
    tapticEngine.trigger("medium");
  };

  return (
    <section
      ref={sectionRef}
      id="experience-section"
      className="relative min-h-[100vh] py-32 flex items-center justify-center overflow-hidden border-t border-[#2a1e16]/60 bg-[#0a0807]"
    >
      {/* Dynamic Background Image Layers with Cross-Fade on Scroll */}
      {images.map((imgUrl, idx) => (
        <div
          key={idx}
          className={`absolute inset-0 z-0 transition-opacity duration-1000 ease-in-out ${
            activeWordIndex === idx ? "opacity-30 scale-105" : "opacity-0 scale-100"
          }`}
          style={{ transitionProperty: "opacity, transform" }}
        >
          <img
            src={imgUrl}
            alt={`Coffee ritual stage ${idx + 1}`}
            className="w-full h-full object-cover filter brightness-75 contrast-110"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-radial-[circle_at_center,transparent_0%,#0a0807_85%]" />
        </div>
      ))}

      <div className="relative z-10 max-w-6xl mx-auto px-6 text-center flex flex-col items-center">
        {/* Section Label */}
        <div className="flex items-center gap-3 mb-10">
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#c59d5f]">
            SECTION {section07.number}
          </span>
          <span className="w-12 h-[1px] bg-[#c59d5f]/40"></span>
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#d6c7b2]">
            THE SENSORY RITUAL
          </span>
        </div>

        {/* 3 Monumental Words: "SLOW DOWN." "POUR." "ENJOY." */}
        <div className="flex flex-col gap-6 md:gap-8 my-4 w-full" id="experience-words-container">
          {section07.words.map((word, index) => {
            const isActive = activeWordIndex === index;
            return (
              <button
                key={index}
                onClick={() => handleWordClick(index)}
                onMouseEnter={() => handleWordClick(index)}
                className={`font-serif-luxury text-5xl sm:text-7xl md:text-8xl lg:text-9xl font-light tracking-tight transition-all duration-700 block focus:outline-none select-none text-center cursor-pointer ${
                  isActive
                    ? "text-[#f4eee6] scale-105 gold-glow"
                    : "text-[#33241b] hover:text-[#78543d]"
                }`}
                id={`experience-word-${index}`}
              >
                {word}
              </button>
            );
          })}
        </div>

        {/* Dynamic Caption that shifts with the active image on scroll */}
        <div className="mt-8 px-6 py-2 rounded-full bg-[#0f0c0a]/80 backdrop-blur-md border border-[#33241b] text-xs font-mono tracking-[0.2em] text-[#c59d5f] transition-all duration-500">
          {imageCaptions[activeWordIndex]}
        </div>

        {/* Subtext description */}
        <p className="mt-6 font-sans text-sm md:text-base uppercase tracking-[0.25em] text-[#a8947f] font-light max-w-lg">
          {section07.subtext}
        </p>

        {/* Interactive / Scroll-linked Visual Pill Selectors */}
        <div className="flex items-center gap-4 mt-8">
          {section07.words.map((_, i) => (
            <button
              key={i}
              onClick={() => handleWordClick(i)}
              className={`h-1.5 transition-all duration-500 rounded-full focus:outline-none cursor-pointer ${
                activeWordIndex === i
                  ? "w-14 bg-[#c59d5f] shadow-[0_0_8px_rgba(197,157,95,0.8)]"
                  : "w-4 bg-[#261b14]"
              }`}
              aria-label={`Select stage ${i + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
