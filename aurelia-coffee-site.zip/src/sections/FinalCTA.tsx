import React from "react";
import { brandConfig } from "../config/brandConfig";
import { ArrowRight, CheckCircle2 } from "lucide-react";

interface FinalCTAProps {
  onShopClick: () => void;
}

export const FinalCTA: React.FC<FinalCTAProps> = ({ onShopClick }) => {
  const { section08 } = brandConfig.content;

  return (
    <section
      id="final-cta-section"
      className="relative py-36 px-6 md:px-12 overflow-hidden border-t border-[#2a1e16] bg-gradient-to-b from-[#0f0c0a] via-[#17110d] to-[#0a0807]"
    >
      {/* Background glow and subtle craft packaging overlay */}
      <div className="absolute inset-0 z-0 opacity-20 pointer-events-none">
        <img
          src={brandConfig.images.craftPackaging}
          alt="Aurelia Craft Roasters"
          className="w-full h-full object-cover object-center filter brightness-50"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0807] via-[#0f0c0a]/80 to-[#0f0c0a]" />
      </div>

      <div className="relative z-10 max-w-4xl mx-auto text-center flex flex-col items-center">
        {/* Section Label */}
        <div className="flex items-center gap-3 mb-6">
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#c59d5f]">
            SECTION {section08.number}
          </span>
          <span className="w-12 h-[1px] bg-[#c59d5f]/40"></span>
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#d6c7b2]">
            THE BEGINNING
          </span>
        </div>

        {/* Dramatic Heading: "YOUR NEXT CUP AWAITS." */}
        <h2
          className="font-serif-luxury text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-light tracking-tight text-[#f4eee6] leading-[1.08] mb-6 gold-glow"
          id="final-cta-heading"
        >
          {section08.heading}
        </h2>

        {/* Supporting text: "Discover coffee made for your everyday moments." */}
        <p
          className="font-sans text-base md:text-xl text-[#d6c7b2] font-light max-w-xl mx-auto leading-relaxed mb-10"
          id="final-cta-subtext"
        >
          {section08.subtext}
        </p>

        {/* Primary CTA Button: [SHOP COFFEE] */}
        <button
          onClick={onShopClick}
          className="inline-flex items-center gap-3 px-10 py-5 bg-[#c59d5f] hover:bg-[#dfbc84] text-[#0f0c0a] text-xs uppercase tracking-[0.25em] font-bold transition-all duration-300 shadow-2xl hover:shadow-[#c59d5f]/30 hover:scale-105 group focus:outline-none"
          id="final-cta-shop-btn"
        >
          <span>{section08.cta}</span>
          <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
        </button>

        {/* Perks list */}
        <div className="mt-16 pt-10 border-t border-[#2a1e16] w-full grid grid-cols-1 sm:grid-cols-3 gap-6 text-left">
          {section08.perks.map((perk, idx) => (
            <div key={idx} className="flex items-start gap-3">
              <CheckCircle2 className="w-4 h-4 text-[#c59d5f] shrink-0 mt-0.5" />
              <span className="text-xs text-[#a8947f] font-light leading-relaxed">
                {perk}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
