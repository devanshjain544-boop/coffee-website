import React from "react";
import { brandConfig } from "../config/brandConfig";
import { ArrowDown, Sparkles } from "lucide-react";

interface HeroProps {
  onExploreClick: () => void;
  onOpenPhilosophy?: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExploreClick, onOpenPhilosophy }) => {
  return (
    <section
      id="hero-section"
      className="relative min-h-screen w-full flex items-center justify-center overflow-hidden pt-24 pb-16 px-6 md:px-12"
    >
      {/* Cinematic subtle radial vignette */}
      <div className="absolute inset-0 bg-radial-[circle_at_center,rgba(244,238,230,0.02)_0%,rgba(15,12,10,0.85)_75%,rgba(15,12,10,0.98)_100%] pointer-events-none z-10" />

      {/* Hero background editorial imagery with depth & warm gradient overlay */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <img
          src={brandConfig.images.heroCoffee}
          alt="Aurelia Artisanal Coffee"
          className="w-full h-full object-cover object-center scale-105 transition-transform duration-1000 ease-out brightness-40 filter contrast-110"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0f0c0a] via-[#0f0c0a]/60 to-[#0f0c0a]/40" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0f0c0a] via-transparent to-[#0f0c0a]" />
      </div>

      {/* Main Content Layout */}
      <div className="relative z-20 max-w-5xl mx-auto text-center flex flex-col items-center">
        {/* Eyebrow badge (Staggered entrance: delay 200ms) */}
        <div
          className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full border border-[#c59d5f]/30 bg-[#1f1712]/60 backdrop-blur-md mb-8 animate-cinematic-up"
          style={{ animationDelay: "200ms" }}
          id="hero-eyebrow"
        >
          <Sparkles className="w-3.5 h-3.5 text-[#c59d5f]" />
          <span className="text-[11px] uppercase tracking-[0.3em] text-[#d6c7b2] font-semibold">
            {brandConfig.content.hero.eyebrow}
          </span>
        </div>

        {/* Brand Name Supertitle (Delay 400ms) */}
        <p
          className="text-xs md:text-sm uppercase tracking-[0.45em] text-[#c59d5f] font-sans font-medium mb-4 animate-cinematic-up"
          style={{ animationDelay: "400ms" }}
          id="hero-brand-name"
        >
          {brandConfig.brand.name}
        </p>

        {/* Main Hero Heading: "THE ART OF A PERFECT CUP" (Delay 600ms) */}
        <h1
          className="font-serif-luxury text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-light tracking-tight text-[#f4eee6] leading-[1.08] max-w-4xl mb-6 gold-glow animate-cinematic-up"
          style={{ animationDelay: "600ms" }}
          id="hero-main-heading"
        >
          {brandConfig.content.hero.title}
        </h1>

        {/* Supporting text: "From carefully selected beans to your daily ritual." (Delay 800ms) */}
        <p
          className="font-sans text-base md:text-xl text-[#d6c7b2] font-light max-w-xl mx-auto leading-relaxed mb-10 text-balance animate-cinematic-up"
          style={{ animationDelay: "800ms" }}
          id="hero-supporting-text"
        >
          {brandConfig.content.hero.subtext}
        </p>

        {/* Action Buttons (Delay 1000ms) */}
        <div
          className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full max-w-md animate-cinematic-up"
          style={{ animationDelay: "1000ms" }}
        >
          <button
            onClick={onExploreClick}
            className="w-full sm:w-auto px-8 py-4 bg-[#c59d5f] hover:bg-[#dfbc84] text-[#0f0c0a] text-xs uppercase tracking-[0.25em] font-semibold transition-all duration-300 shadow-xl hover:shadow-2xl hover:shadow-[#c59d5f]/25 transform hover:-translate-y-0.5 focus:outline-none"
            id="hero-explore-btn"
          >
            {brandConfig.content.hero.primaryCta}
          </button>

          {onOpenPhilosophy && (
            <button
              onClick={onOpenPhilosophy}
              className="w-full sm:w-auto px-8 py-4 border border-[#443328] hover:border-[#c59d5f] text-[#d6c7b2] hover:text-[#f4eee6] text-xs uppercase tracking-[0.25em] font-medium bg-[#140f0c]/50 backdrop-blur-sm transition-all duration-300 focus:outline-none"
              id="hero-philosophy-btn"
            >
              {brandConfig.content.hero.secondaryCta}
            </button>
          )}
        </div>

        {/* Floating subtle scroll indicator (Delay 1200ms) */}
        <div
          onClick={onExploreClick}
          style={{ animationDelay: "1200ms" }}
          className="mt-16 md:mt-24 cursor-pointer flex flex-col items-center gap-2 text-[#a8947f] hover:text-[#c59d5f] transition-colors duration-300 group animate-cinematic-up"
        >
          <span className="text-[10px] uppercase tracking-[0.3em] font-medium">
            Scroll to Discover
          </span>
          <ArrowDown className="w-4 h-4 animate-bounce group-hover:text-[#c59d5f]" />
        </div>
      </div>
    </section>
  );
};
