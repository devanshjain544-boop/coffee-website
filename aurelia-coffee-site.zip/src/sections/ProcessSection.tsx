import React, { useState } from "react";
import { brandConfig } from "../config/brandConfig";

export const ProcessSection: React.FC = () => {
  const { section03 } = brandConfig.content;
  const [activeStage, setActiveStage] = useState(0);

  return (
    <section
      id="process-section"
      className="relative py-32 px-6 md:px-12 max-w-7xl mx-auto border-t border-[#2a1e16]/60"
    >
      {/* Section Header */}
      <div className="mb-20 max-w-3xl">
        <div className="flex items-center gap-3 mb-4">
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#c59d5f]">
            SECTION {section03.number}
          </span>
          <span className="w-12 h-[1px] bg-[#c59d5f]/40"></span>
        </div>
        <h2
          className="font-serif-luxury text-4xl sm:text-6xl md:text-7xl font-light tracking-tight text-[#f4eee6] leading-[1.1] mb-4"
          id="process-section-heading"
        >
          {section03.heading}
        </h2>
        <p className="text-xs uppercase tracking-[0.3em] text-[#c59d5f] font-mono">
          {section03.subheading}
        </p>
      </div>

      {/* 4 Stages Horizontal Story Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6" id="process-stages-grid">
        {section03.stages.map((stage, idx) => {
          const isSelected = activeStage === idx;
          return (
            <div
              key={idx}
              onMouseEnter={() => setActiveStage(idx)}
              className={`relative cursor-pointer transition-all duration-500 p-8 border flex flex-col justify-between min-h-[420px] ${
                isSelected
                  ? "bg-[#1c1511] border-[#c59d5f] shadow-2xl shadow-[#c59d5f]/10"
                  : "bg-[#140f0c] border-[#2a1e16] hover:border-[#443328]"
              }`}
            >
              {/* Card Header: Step Number & Title */}
              <div>
                <div className="flex justify-between items-start mb-6">
                  <span
                    className={`font-mono text-3xl font-light transition-colors ${
                      isSelected ? "text-[#c59d5f]" : "text-[#554033]"
                    }`}
                  >
                    {stage.step}
                  </span>
                  <div
                    className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                      isSelected ? "bg-[#c59d5f] scale-125" : "bg-[#33241b]"
                    }`}
                  />
                </div>

                <h3 className="font-serif-luxury text-3xl font-light text-[#f4eee6] tracking-wide mb-3">
                  {stage.title}
                </h3>

                <p className="text-xs text-[#a8947f] font-light leading-relaxed mb-6">
                  {stage.description}
                </p>
              </div>

              {/* Stage Visual Thumbnail */}
              <div className="relative aspect-[4/3] w-full overflow-hidden rounded-sm border border-[#2a1e16] bg-[#080605] mt-auto">
                <img
                  src={stage.image}
                  alt={`Stage ${stage.step} - ${stage.title}`}
                  className={`w-full h-full object-cover transition-all duration-700 ${
                    isSelected ? "scale-105 filter-none" : "grayscale-[40%] scale-100"
                  }`}
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0f0c0a] via-transparent to-transparent opacity-60" />
              </div>

              {/* Bottom active accent bar */}
              <div
                className={`absolute bottom-0 left-0 right-0 h-1 transition-all duration-500 ${
                  isSelected ? "bg-[#c59d5f]" : "bg-transparent"
                }`}
              />
            </div>
          );
        })}
      </div>

      {/* Progress Timeline Indicator */}
      <div className="mt-12 flex items-center justify-between border-t border-[#2a1e16] pt-8 text-xs font-mono uppercase tracking-[0.2em] text-[#a8947f]">
        <span>01 / HARVEST</span>
        <div className="flex-1 mx-8 h-[1px] bg-[#2a1e16] relative">
          <div
            className="h-[2px] bg-[#c59d5f] transition-all duration-500"
            style={{ width: `${((activeStage + 1) / 4) * 100}%` }}
          />
        </div>
        <span>04 / EXTRACTION</span>
      </div>
    </section>
  );
};
