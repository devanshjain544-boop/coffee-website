import React from "react";
import { brandConfig } from "../config/brandConfig";
import { Sparkles, ArrowRight } from "lucide-react";

interface SignatureSectionProps {
  onDiscoverBlend: () => void;
}

export const SignatureSection: React.FC<SignatureSectionProps> = ({ onDiscoverBlend }) => {
  const { section04 } = brandConfig.content;

  return (
    <section
      id="signature-section"
      className="relative py-32 px-6 md:px-12 max-w-7xl mx-auto border-t border-[#2a1e16]/60 overflow-hidden"
    >
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
        {/* Left Column (5 cols): Product Visual Showcase (Main Focus) */}
        <div className="lg:col-span-6 order-2 lg:order-1">
          <div className="relative group">
            {/* Ambient golden back-glow */}
            <div className="absolute -inset-4 bg-gradient-to-r from-[#c59d5f]/15 to-[#8f6735]/15 blur-2xl rounded-3xl -z-10 group-hover:opacity-100 transition-opacity duration-700 opacity-60" />

            <div className="relative aspect-[4/5] w-full overflow-hidden border border-[#3d2b20] bg-[#120e0b] shadow-2xl">
              <img
                src={brandConfig.images.signatureCup}
                alt="Aurelia Signature Cup Pour with Golden Crema"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000 ease-out"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0f0c0a] via-transparent to-transparent opacity-70" />

              {/* Gold seal badge */}
              <div className="absolute top-6 left-6 p-4 bg-[#0f0c0a]/90 backdrop-blur-md border border-[#c59d5f]/50 flex items-center gap-3">
                <Sparkles className="w-4 h-4 text-[#c59d5f]" />
                <span className="text-[10px] uppercase font-mono tracking-[0.25em] text-[#f4eee6]">
                  ROASTER'S RESERVE • MICROLOT 01
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (7 cols): Editorial Presentation & Typography */}
        <div className="lg:col-span-6 order-1 lg:order-2 flex flex-col justify-center">
          <div className="flex items-center gap-3 mb-4">
            <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#c59d5f]">
              SECTION {section04.number}
            </span>
            <span className="w-12 h-[1px] bg-[#c59d5f]/40"></span>
          </div>

          <h2
            className="font-serif-luxury text-4xl sm:text-6xl md:text-7xl font-light tracking-tight text-[#f4eee6] leading-[1.1] mb-6"
            id="signature-section-heading"
          >
            {section04.heading}
          </h2>

          <p className="font-serif-luxury text-xl sm:text-2xl text-[#d6c7b2] font-light italic leading-relaxed mb-8">
            "{section04.description}"
          </p>

          {/* Tasting Note Breakdown */}
          <div className="space-y-4 mb-10 border-y border-[#2a1e16] py-6">
            {section04.details.map((detail, idx) => (
              <div key={idx} className="flex flex-col sm:flex-row sm:items-baseline gap-2 sm:gap-6">
                <span className="text-xs font-mono uppercase tracking-[0.25em] text-[#c59d5f] w-24">
                  {detail.title}
                </span>
                <span className="text-sm font-light text-[#a8947f]">
                  {detail.desc}
                </span>
              </div>
            ))}
          </div>

          {/* Action Button: [DISCOVER THE BLEND] */}
          <div>
            <button
              onClick={onDiscoverBlend}
              className="inline-flex items-center gap-3 px-8 py-4 bg-[#c59d5f] hover:bg-[#dfbc84] text-[#0f0c0a] text-xs uppercase tracking-[0.25em] font-semibold transition-all duration-300 shadow-xl hover:shadow-[#c59d5f]/20 group focus:outline-none"
              id="signature-discover-btn"
            >
              <span>{section04.cta}</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
