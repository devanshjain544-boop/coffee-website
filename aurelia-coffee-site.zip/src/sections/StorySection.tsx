import React from "react";
import { brandConfig } from "../config/brandConfig";

export const StorySection: React.FC = () => {
  const { section06 } = brandConfig.content;

  return (
    <section
      id="story-section"
      className="relative py-32 px-6 md:px-12 max-w-7xl mx-auto border-t border-[#2a1e16]/60"
    >
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
        {/* Left Column (6 cols): Large Editorial Coffee Image */}
        <div className="lg:col-span-6">
          <div className="relative group">
            {/* Decorative offset frame */}
            <div className="absolute -inset-3 border border-[#c59d5f]/30 -z-10 translate-x-3 translate-y-3 transition-transform group-hover:translate-x-4 group-hover:translate-y-4 duration-500" />

            <div className="relative aspect-[3/4] w-full overflow-hidden bg-[#110d0a] border border-[#33241b]">
              <img
                src={brandConfig.images.storyLandscape}
                alt="Aurelia High Altitude Coffee Estate Landscape"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000 ease-out filter brightness-90"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0f0c0a] via-transparent to-transparent opacity-60" />

              {/* Editorial caption */}
              <div className="absolute bottom-6 left-6 right-6 p-4 bg-[#0f0c0a]/80 backdrop-blur-md border border-[#33241b]/60">
                <p className="font-serif-luxury text-sm text-[#f4eee6] italic">
                  "Respecting the land, honoring the farmer, elevating the cup."
                </p>
                <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-[#c59d5f] mt-1 block">
                  Sierra Nevada Reserve, 1,950m
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (6 cols): Brand Story Narrative */}
        <div className="lg:col-span-6 flex flex-col justify-center">
          <div className="flex items-center gap-3 mb-4">
            <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#c59d5f]">
              SECTION {section06.number}
            </span>
            <span className="w-12 h-[1px] bg-[#c59d5f]/40"></span>
          </div>

          <h2
            className="font-serif-luxury text-4xl sm:text-6xl md:text-7xl font-light tracking-tight text-[#f4eee6] leading-[1.1] mb-8"
            id="story-section-heading"
          >
            {section06.heading}
          </h2>

          {/* Editorial Paragraphs */}
          <div className="space-y-6 text-sm md:text-base font-light text-[#d6c7b2] leading-relaxed mb-10">
            {section06.story.map((para, idx) => (
              <p key={idx} className="first-letter:text-4xl first-letter:font-serif first-letter:text-[#c59d5f] first-letter:float-left first-letter:mr-2 first-letter:leading-none">
                {para}
              </p>
            ))}
          </div>

          {/* Signature & Title */}
          <div className="pt-6 border-t border-[#2a1e16] flex items-center justify-between">
            <div>
              <p className="font-serif-luxury text-2xl text-[#f4eee6] italic font-light">
                {section06.signatureName}
              </p>
              <p className="text-xs font-mono uppercase tracking-[0.2em] text-[#c59d5f]">
                {section06.signatureTitle}
              </p>
            </div>

            <div className="font-serif text-3xl text-[#a8947f]/40 tracking-widest italic select-none">
              Aurelia
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
