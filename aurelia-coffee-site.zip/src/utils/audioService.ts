/**
 * Aurelia Coffee - Luxury Web Audio Ambient & Pour Synthesizer
 * Uses Web Audio API for zero-latency, zero-dependency organic acoustic coffee pouring & ambient warmth.
 * Mandatory ambient soundscape and sensory audio.
 */

class LuxuryAudioService {
  private ctx: AudioContext | null = null;
  private isPlayingExperience: boolean = false;
  private masterGain: GainNode | null = null;
  private experienceGain: GainNode | null = null;
  private ambientNoiseNode: AudioNode | null = null;
  private dropletInterval: number | null = null;
  private listeners: ((isMuted: boolean, isPlaying: boolean) => void)[] = [];

  constructor() {
    if (typeof window !== "undefined") {
      // Auto-unlock audio context on first user interaction
      const unlockAudio = () => {
        this.initContext();
        window.removeEventListener("scroll", unlockAudio);
        window.removeEventListener("wheel", unlockAudio);
        window.removeEventListener("touchstart", unlockAudio);
        window.removeEventListener("touchmove", unlockAudio);
        window.removeEventListener("pointerdown", unlockAudio);
        window.removeEventListener("keydown", unlockAudio);
      };

      window.addEventListener("scroll", unlockAudio, { passive: true, once: true });
      window.addEventListener("wheel", unlockAudio, { passive: true, once: true });
      window.addEventListener("touchstart", unlockAudio, { passive: true, once: true });
      window.addEventListener("touchmove", unlockAudio, { passive: true, once: true });
      window.addEventListener("pointerdown", unlockAudio, { passive: true, once: true });
      window.addEventListener("keydown", unlockAudio, { passive: true, once: true });
    }
  }

  public subscribe(cb: (isMuted: boolean, isPlaying: boolean) => void) {
    this.listeners.push(cb);
    cb(false, this.isPlayingExperience);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== cb);
    };
  }

  private notify() {
    this.listeners.forEach((l) => l(false, this.isPlayingExperience));
  }

  private initContext() {
    if (!this.ctx && typeof window !== "undefined") {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.setValueAtTime(0.45, this.ctx.currentTime);
        this.masterGain.connect(this.ctx.destination);

        this.experienceGain = this.ctx.createGain();
        this.experienceGain.gain.setValueAtTime(0, this.ctx.currentTime);
        this.experienceGain.connect(this.masterGain);
      }
    }
    if (this.ctx && this.ctx.state === "suspended") {
      this.ctx.resume().catch(() => {});
    }
  }

  /**
   * Generates organic stream of fluid liquid pouring (filtered colored noise with subtle frequency oscillation)
   */
  private startPourGenerator() {
    if (!this.ctx || !this.experienceGain) return;

    // 1. Create a 3-second looping pink noise buffer for warm fluid sound
    const bufferSize = this.ctx.sampleRate * 3;
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      b3 = 0.86650 * b3 + white * 0.3104856;
      b4 = 0.55000 * b4 + white * 0.5329522;
      b5 = -0.7616 * b5 - white * 0.0168980;
      output[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.08;
      b6 = white * 0.115926;
    }

    const noiseSource = this.ctx.createBufferSource();
    noiseSource.buffer = noiseBuffer;
    noiseSource.loop = true;

    // Resonant bandpass filter mimicking liquid streaming into a porcelain vessel (500Hz - 900Hz)
    const filter = this.ctx.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.setValueAtTime(650, this.ctx.currentTime);
    filter.Q.setValueAtTime(2.2, this.ctx.currentTime);

    // Subtle gentle fluid flow LFO modulation
    const lfo = this.ctx.createOscillator();
    lfo.frequency.setValueAtTime(0.8, this.ctx.currentTime);
    const lfoGain = this.ctx.createGain();
    lfoGain.gain.setValueAtTime(140, this.ctx.currentTime);
    lfo.connect(lfoGain);
    lfoGain.connect(filter.frequency);

    // Gentle sub-harmonic resonance for ceramic cup body
    const subOsc = this.ctx.createOscillator();
    subOsc.type = "sine";
    subOsc.frequency.setValueAtTime(180, this.ctx.currentTime);
    const subGain = this.ctx.createGain();
    subGain.gain.setValueAtTime(0.015, this.ctx.currentTime);
    subOsc.connect(subGain);
    subGain.connect(this.experienceGain);

    noiseSource.connect(filter);
    filter.connect(this.experienceGain);

    noiseSource.start();
    lfo.start();
    subOsc.start();

    this.ambientNoiseNode = noiseSource;

    // 2. Add delicate sporadic liquid droplet plops
    this.dropletInterval = window.setInterval(() => {
      if (!this.isPlayingExperience) return;
      this.playDroplet();
    }, 450);
  }

  private playDroplet() {
    if (!this.ctx || !this.experienceGain) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      // Pitch sweep mimicking water/coffee droplet surface impact
      const startFreq = 900 + Math.random() * 800;
      const endFreq = startFreq + 150 + Math.random() * 200;

      osc.type = "sine";
      osc.frequency.setValueAtTime(startFreq, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(endFreq, this.ctx.currentTime + 0.04);

      gain.gain.setValueAtTime(0.025 + Math.random() * 0.02, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 0.06);

      osc.connect(gain);
      gain.connect(this.experienceGain);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.07);
    } catch {
      // Ignore transient audio graph errors
    }
  }

  public triggerExperienceEnter() {
    this.initContext();
    if (!this.ctx || !this.experienceGain) return;

    if (!this.isPlayingExperience) {
      this.isPlayingExperience = true;
      this.notify();

      if (!this.ambientNoiseNode) {
        this.startPourGenerator();
      }

      // Smooth luxury fade-in over 1.4 seconds
      const now = this.ctx.currentTime;
      this.experienceGain.gain.cancelScheduledValues(now);
      this.experienceGain.gain.setValueAtTime(this.experienceGain.gain.value, now);
      this.experienceGain.gain.linearRampToValueAtTime(0.65, now + 1.4);
    }
  }

  public triggerExperienceLeave() {
    if (!this.ctx || !this.experienceGain) return;

    if (this.isPlayingExperience) {
      this.isPlayingExperience = false;
      this.notify();

      // Gentle fade-out over 1.2 seconds
      const now = this.ctx.currentTime;
      this.experienceGain.gain.cancelScheduledValues(now);
      this.experienceGain.gain.setValueAtTime(this.experienceGain.gain.value, now);
      this.experienceGain.gain.linearRampToValueAtTime(0, now + 1.2);
    }
  }

  public getIsMuted(): boolean {
    return false;
  }

  public getIsPlaying(): boolean {
    return this.isPlayingExperience;
  }
}

export const audioService = new LuxuryAudioService();
