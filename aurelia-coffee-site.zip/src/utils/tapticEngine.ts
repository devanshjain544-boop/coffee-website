/**
 * Aurelia Coffee - Universal Taptic & Vibration Engine
 * Specifically engineered for:
 * 1. Mobile Phones (Physical Motor Vibration via navigator.vibrate)
 * 2. Laptops & iPhones (Chassis-Vibrating Low-Frequency Speaker Excursion + Precision Detent Clicks)
 * 3. Compulsory Downward Scroll Triggering (wheel deltaY > 0, touchmove down, window scroll down)
 */

export type TapticIntensity = "light" | "medium" | "heavy" | "section";

class TapticEngine {
  private audioCtx: AudioContext | null = null;
  private lastScrollY: number = 0;
  private lastTouchY: number = 0;
  private lastTriggerTime: number = 0;
  private isUnlocked: boolean = false;
  private hasVibrator: boolean = false;

  constructor() {
    if (typeof window !== "undefined") {
      this.hasVibrator = "vibrate" in navigator;

      // Unlock on earliest user gesture (touch, wheel, pointer, click, keydown, scroll)
      const unlock = () => {
        this.unlockContext();
        window.removeEventListener("pointerdown", unlock);
        window.removeEventListener("touchstart", unlock);
        window.removeEventListener("wheel", unlock);
        window.removeEventListener("keydown", unlock);
        window.removeEventListener("scroll", unlock);
      };

      window.addEventListener("pointerdown", unlock, { passive: true, once: true });
      window.addEventListener("touchstart", unlock, { passive: true, once: true });
      window.addEventListener("wheel", unlock, { passive: true, once: true });
      window.addEventListener("keydown", unlock, { passive: true, once: true });
      window.addEventListener("scroll", unlock, { passive: true, once: true });

      // 1. Laptop Trackpad & Desktop Wheel Downward Scroll
      window.addEventListener(
        "wheel",
        (e) => {
          this.unlockContext();
          // Downward scroll has positive deltaY
          if (e.deltaY > 3) {
            const now = Date.now();
            if (now - this.lastTriggerTime >= 50) {
              this.lastTriggerTime = now;
              this.trigger("light");
            }
          }
        },
        { passive: true }
      );

      // 2. Mobile Phone Touchscreen Downward Scroll (Finger dragging upwards to scroll down)
      window.addEventListener(
        "touchstart",
        (e) => {
          this.unlockContext();
          if (e.touches.length > 0) {
            this.lastTouchY = e.touches[0].clientY;
          }
        },
        { passive: true }
      );

      window.addEventListener(
        "touchmove",
        (e) => {
          if (e.touches.length > 0) {
            const currentY = e.touches[0].clientY;
            const diff = this.lastTouchY - currentY; // positive when dragging up to scroll DOWN
            const now = Date.now();

            if (diff >= 35 && now - this.lastTriggerTime >= 45) {
              this.lastTouchY = currentY;
              this.lastTriggerTime = now;
              this.trigger("medium");
            }
          }
        },
        { passive: true }
      );

      // 3. Global Window Scroll Downward Watcher
      window.addEventListener(
        "scroll",
        () => {
          this.unlockContext();
          const currentY = window.pageYOffset || document.documentElement.scrollTop || 0;
          const delta = currentY - this.lastScrollY;

          // Detect scrolling DOWN
          if (delta >= 45) {
            const now = Date.now();
            if (now - this.lastTriggerTime >= 45) {
              this.lastScrollY = currentY;
              this.lastTriggerTime = now;
              this.trigger("light");
            }
          } else if (delta < -30) {
            // Keep track of upward scroll position without triggering
            this.lastScrollY = currentY;
          }
        },
        { passive: true }
      );
    }
  }

  private unlockContext() {
    if (!this.audioCtx && typeof window !== "undefined") {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.audioCtx = new AudioCtx();
      }
    }
    if (this.audioCtx && this.audioCtx.state === "suspended") {
      this.audioCtx.resume().catch(() => {});
    }
    this.isUnlocked = true;
  }

  /**
   * Main vibration & taptic trigger:
   * Vibrates mobile phone hardware AND laptop chassis
   */
  public trigger(intensity: TapticIntensity = "light") {
    this.unlockContext();

    // 1. Physical Smartphone Hardware Vibration (Android / Chrome Mobile)
    if (this.hasVibrator && typeof navigator !== "undefined" && navigator.vibrate) {
      try {
        if (intensity === "light") {
          navigator.vibrate(25); // 25ms crisp pulse
        } else if (intensity === "medium") {
          navigator.vibrate(35); // 35ms solid pulse
        } else if (intensity === "heavy") {
          navigator.vibrate([40, 30, 40]);
        } else if (intensity === "section") {
          navigator.vibrate([45, 35, 45]);
        }
      } catch {
        // Handled silently
      }
    }

    // 2. Physical Laptop Chassis Vibration + Precision Acoustic Detent (MacBook, Windows Laptop, iPhone)
    this.playChassisVibration(intensity);
  }

  /**
   * Creates physical laptop chassis vibration through low-frequency speaker excursion (55Hz)
   * combined with high-frequency mechanical detent clicks (2100Hz)
   */
  private playChassisVibration(intensity: TapticIntensity) {
    if (!this.audioCtx) return;

    try {
      const now = this.audioCtx.currentTime;
      const master = this.audioCtx.destination;

      // Layer A: Low-frequency sub-bass transducer pulse
      // Pushes the laptop speaker cones with high excursion to physically vibrate aluminum palm rests
      const subOsc = this.audioCtx.createOscillator();
      const subGain = this.audioCtx.createGain();

      subOsc.type = "sine";
      const freq = intensity === "section" ? 48 : 55;
      subOsc.frequency.setValueAtTime(freq, now);
      subOsc.frequency.exponentialRampToValueAtTime(30, now + 0.03);

      const subVol = intensity === "section" ? 0.35 : intensity === "heavy" ? 0.3 : 0.22;
      subGain.gain.setValueAtTime(subVol, now);
      subGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.03);

      subOsc.connect(subGain);
      subGain.connect(master);

      subOsc.start(now);
      subOsc.stop(now + 0.032);

      // Layer B: Sharp rotary detent click (Apple Watch / Leica dial sensation)
      const clickOsc = this.audioCtx.createOscillator();
      const clickGain = this.audioCtx.createGain();
      const clickFilter = this.audioCtx.createBiquadFilter();

      clickFilter.type = "bandpass";
      clickFilter.frequency.setValueAtTime(intensity === "section" ? 1500 : 2200, now);
      clickFilter.Q.setValueAtTime(3.5, now);

      clickOsc.type = intensity === "section" ? "triangle" : "sine";
      clickOsc.frequency.setValueAtTime(intensity === "section" ? 1100 : 2400, now);
      clickOsc.frequency.exponentialRampToValueAtTime(700, now + 0.012);

      const clickVol = intensity === "section" ? 0.12 : 0.08;
      clickGain.gain.setValueAtTime(clickVol, now);
      clickGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.012);

      clickOsc.connect(clickFilter);
      clickFilter.connect(clickGain);
      clickGain.connect(master);

      clickOsc.start(now);
      clickOsc.stop(now + 0.013);
    } catch {
      // Ignored
    }
  }

  /**
   * Directly test or force a haptic tick
   */
  public testPulse() {
    this.unlockContext();
    this.trigger("medium");
  }
}

export const tapticEngine = new TapticEngine();
